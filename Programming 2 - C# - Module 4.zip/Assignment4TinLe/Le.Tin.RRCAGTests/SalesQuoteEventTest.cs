﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Le.Tin.Business;

namespace Le.Tin.RRCAGTests
{
    internal class SalesQuoteEventTest
    {
        static void Main(string[] args)
        {
            // SalesQuote class events test
            decimal vehicleSalePrice = 300m;
            decimal tradeInAmount = 100m;
            decimal salesTaxRate = 0.15m;
            Accessories accessoriesChosen = Accessories.StereoAndLeather;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.Standard;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            salesQuote.VehiclePriceChanged += SalesQuote_VehiclePriceChanged;
            salesQuote.VehicleSalePrice = 400m;

            salesQuote.TradeInAmountChanged += SalesQuote_TradeInAmountChanged; 
            salesQuote.TradeInAmount = 200m;

            salesQuote.AccessoriesChosenChanged += SalesQuote_AccessoriesChosenChanged;
            salesQuote.AccessoriesChosen = Accessories.ComputerNavigation;

            salesQuote.ExteriorFinishChosenChanged += SalesQuote_ExteriorFinishChosenChanged;
            salesQuote.ExteriorFinishChosen = ExteriorFinish.Pearlized;

            // Invoice class events test
            decimal provincialSalesTaxRate = 0.15m;
            decimal goodsAndServicesTaxRate = 0.2m;

            CarWashInvoice invoice = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);

            invoice.ProvincialSalesTaxRateChanged += Invoice_ProvincialSalesTaxRateChanged;
            invoice.ProvincialSalesTaxRate = 0.3m;

            invoice.GoodsAndServicesTaxRateChanged += Invoice_GoodsAndServicesTaxRateChanged;
            invoice.GoodsAndServicesTaxRate = 0.25m;

            //CarWashInvoice class events test
            decimal provincialSalesTaxRate2 = 0.15m;
            decimal goodsAndServicesTaxRate2 = 0.2m;
            decimal packageCost = 200m;
            decimal fragranceCost = 100m;

            CarWashInvoice carWashInvoice = new CarWashInvoice(provincialSalesTaxRate2, goodsAndServicesTaxRate2, packageCost, fragranceCost);

            carWashInvoice.PackageCostChanged += CarWashInvoice_PackageCostChanged;
            carWashInvoice.PackageCost = 300m;

            carWashInvoice.FragranceCostChanged += CarWashInvoice_FragranceCostChanged;
            carWashInvoice.FragranceCost = 200m;
        }

        private static void SalesQuote_VehiclePriceChanged(object sender, EventArgs e)
        {
            Console.WriteLine("The price of the vehicle being quoted on has been changed");
        }

        private static void SalesQuote_TradeInAmountChanged(object sender, EventArgs e)
        {
            Console.WriteLine("The amount for the trade in vehicle has been changed");
        }

        private static void SalesQuote_AccessoriesChosenChanged(object sender, EventArgs e)
        {
            Console.WriteLine("The chosen accessories have been changed");
        }

        private static void SalesQuote_ExteriorFinishChosenChanged(object sender, EventArgs e)
        {
            Console.WriteLine("The chosen exterior finish has been changed");
        }

        private static void Invoice_ProvincialSalesTaxRateChanged(object sender, EventArgs e)
        {
            Console.WriteLine("The provincial sales tax rate of the Invoice has been changed.");
        }

        private static void Invoice_GoodsAndServicesTaxRateChanged(object sender, EventArgs e)
        {
            Console.WriteLine("The goods and services tax rate of the Invoice has been changed.");
        }

        private static void CarWashInvoice_PackageCostChanged(object sender, EventArgs e)
        {
            Console.WriteLine("The package cost has been changed.");
        }

        private static void CarWashInvoice_FragranceCostChanged(object sender, EventArgs e)
        {
            Console.WriteLine("The fragrance cost has been changed.");
        }
    }
}
