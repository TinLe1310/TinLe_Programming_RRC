﻿/*
 * Name: Tin Le
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-09-13
 * Updated: 2022-09-14
 */

using System;

namespace Le.Tin.Business
{
    /// <summary>
    /// This abstract class contains functionality that supports the business process of creating an invoice.
    /// </summary>
    public abstract class Invoice
    {
        private decimal provincialSalesTaxRate;
        private decimal goodsAndServicesTaxRate;

        /// <summary>
        /// Occurs when the provincial sales tax rate of the Invoice changes.
        /// </summary>
        public event EventHandler ProvincialSalesTaxRateChanged;
        
        /// <summary>
        /// Occurs when the goods and services tax rate of the Invoice changes.
        /// </summary>
        public event EventHandler GoodsAndServicesTaxRateChanged;

        /// <summary>
        /// Gets and sets the provincial sales tax rate.
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Thrown when the provincial sales tax rate is less than 0 or greater than 1. 
        /// </exception>
        public decimal ProvincialSalesTaxRate
        {
            get
            {
                return provincialSalesTaxRate;
            }
            set
            {           
                if (value < 0 || value > 1)
                {
                    ArgumentOutOfRangeException exception;
                    exception = new ArgumentOutOfRangeException("value", value < 0 ? "The value cannot be less than 0." : "The value cannot be greater than 1.");
                    throw exception;
                }

                if (this.provincialSalesTaxRate != value)
                {
                    this.provincialSalesTaxRate = value;

                    OnProvincialSalesTaxRateChanged();
                }
            }
        }

        /// <summary>
        /// Gets and sets the goods and services tax rate.
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Thrown when the goods and services tax rate is less than 0 or greater than 1. 
        /// </exception>
        public decimal GoodsAndServicesTaxRate
        {
            get
            {
                return goodsAndServicesTaxRate;
            }
            set
            {                
                if (value < 0 || value > 1)
                {
                    ArgumentOutOfRangeException exception;
                    exception = new ArgumentOutOfRangeException("value", value < 0 ? "The value cannot be less than 0." : "The value cannot be greater than 1.");
                    throw exception;
                }

                if (this.goodsAndServicesTaxRate != value)
                {
                    this.goodsAndServicesTaxRate = value;

                    OnGoodsAndServicesTaxRateChanged();
                }
            }
        }

        /// <summary>
        /// Gets the amount of provincial sales tax charged to the customer (Rounded to two decimal places).
        /// </summary>
        public abstract decimal ProvincialSalesTaxCharged
        {
            get;
        }

        /// <summary>
        /// Gets the amount of goods and services tax charged to the customer (Rounded to two decimal places).
        /// </summary>
        public abstract decimal GoodsAndServicesTaxCharged
        {
            get;
        }

        /// <summary>
        /// Gets the subtotal of the Invoice.
        /// </summary>
        public abstract decimal SubTotal
        {
            get;
        }

        /// <summary>
        /// Gets the total of the Invoice. The total is the sum of the subtotal and taxes.
        /// </summary>
        public decimal Total
        {
            get
            {
                return (SubTotal + ProvincialSalesTaxCharged + GoodsAndServicesTaxCharged);
            }
        }

        /// <summary>
        /// Initializes an instance of Invoice with a provincial and goods and services tax rates.
        /// </summary>
        /// <param name="provincialSalesTaxRate">The rate of provincial tax charged to a customer.</param>
        /// <param name="goodsAndServicesTaxRate">The rate of goods and services tax charged to a customer.</param>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Thrown when the provincial sales tax rate is less than 0 or greater than 1. 
        /// </exception>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Thrown when the goods and services tax rate is less than 0 or greater than 1. 
        /// </exception>
        public Invoice(decimal provincialSalesTaxRate, decimal goodsAndServicesTaxRate)
        {
            if (provincialSalesTaxRate < 0 || provincialSalesTaxRate > 1)
            {
                ArgumentOutOfRangeException exception;
                exception = new ArgumentOutOfRangeException("provincialSalesTaxRate", provincialSalesTaxRate < 0 ? "The argument cannot be less than 0." : "The argument cannot be greater than 1.");
                throw exception;
            }

            if (goodsAndServicesTaxRate < 0 || goodsAndServicesTaxRate > 1)
            {
                ArgumentOutOfRangeException exception;
                exception = new ArgumentOutOfRangeException("goodsAndServicesTaxRate", goodsAndServicesTaxRate < 0 ? "The argument cannot be less than 0." : "The argument cannot be greater than 1.");
                throw exception;
            }

            this.ProvincialSalesTaxRate = provincialSalesTaxRate;
            this.GoodsAndServicesTaxRate = goodsAndServicesTaxRate;
        }

        /// <summary>
        /// Raises the ProvincialSalesTaxRateChanged event.
        /// </summary>
        protected virtual void OnProvincialSalesTaxRateChanged()
        {
            if (ProvincialSalesTaxRateChanged != null)
            {
                ProvincialSalesTaxRateChanged(this, new EventArgs());
            }
        }

        /// <summary>
        /// Raises the GoodsAndServicesTaxRateChanged event.
        /// </summary>
        protected virtual void OnGoodsAndServicesTaxRateChanged()
        {
            if (GoodsAndServicesTaxRateChanged != null)
            {
                GoodsAndServicesTaxRateChanged(this, new EventArgs());
            }
        }
    }
}