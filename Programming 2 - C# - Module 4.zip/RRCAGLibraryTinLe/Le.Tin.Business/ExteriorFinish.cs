﻿/*
 * Name: Tin Le
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-09-13
 * Updated: 2022-09-14
 */

namespace Le.Tin.Business
{
    /// <summary>
    /// The Exterior finish enumeration has the following values:
    /// </summary>
    public enum ExteriorFinish
    {
        /// <summary>
        /// Standard - The standard exterior finish.
        /// </summary>
        Standard = 0,

        /// <summary>
        /// Pearlized - The pearlized exterior finish.
        /// </summary>
        Pearlized = 1,

        /// <summary>
        /// Custom - The custom exterior finish.
        /// </summary>
        Custom = 2,

        /// <summary>
        /// None - None of the exterior finishes.
        /// </summary>
        None = 3
    }
}