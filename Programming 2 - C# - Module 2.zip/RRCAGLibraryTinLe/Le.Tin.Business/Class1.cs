﻿/*
 * Name: Tin Le
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-09-13
 * Updated: 2022-09-14
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Le.Tin.Business
{
    public class Class1
    { 
    }
}
