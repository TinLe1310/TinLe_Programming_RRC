﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Le.Tin.Business;

namespace Le.Tin.RRCAGTests
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Testing Method - GetPayment(decimal, int, decimal) : decimal");
            Console.WriteLine("Test #1 - Rate exception < 0");
            Param_NegativeRate_Exception();
            Console.WriteLine("Test #2 - Rate exception > 1");
            Param_RateGreaterThanOne_Exception();
            Console.WriteLine("Test #3 - Number of payment periods exception < 0");
            Param_NegativeNumberOfPaymentPeriods_Exception();
            Console.WriteLine("Test #4 - Number of payment periods exception = 0");
            Param_NumberOfPaymentPeriodsZero_Exception();
            Console.WriteLine("Test #5 - Present value exception < 0");
            Param_NegativePresentValue_Exception();
            Console.WriteLine("Test #6 - Present value exception = 0");
            Param_PresentValueZero_Exception();
            Console.WriteLine("Test #7 - Successful instance initialization");
            Successful_Value_Calculated();

            Console.ReadKey();
        }

        /*
         * Method - GetPayment(decimal, int, decimal) : decimal
         */
        public static void Param_NegativeRate_Exception()
        {
            decimal rate = -0.8M;
            int numberOfPeriods = 10;
            decimal presentValue = 450M;

            string expected = "The argument cannot be less than 0.\nParameter name: rate";
            string actual = "";

            try
            {
                decimal target = Financial.GetPayment(rate, numberOfPeriods, presentValue);
            }
            catch (ArgumentOutOfRangeException exception)
            {
                actual = exception.Message;
            }

            Console.Write("Expected: {0}\nActual: {1}\n\n\n", expected, actual);
        }

        public static void Param_RateGreaterThanOne_Exception()
        {
            decimal rate = 1.8M;
            int numberOfPeriods = 10;
            decimal presentValue = 450M;

            string expected = "The argument cannot be greater than 1.\nParameter name: rate";
            string actual = "";

            try
            {
                decimal target = Financial.GetPayment(rate, numberOfPeriods, presentValue);
            }
            catch (ArgumentOutOfRangeException exception)
            {
                actual = exception.Message;
            }

            Console.Write("Expected: {0}\nActual: {1}\n\n\n", expected, actual);
        }

        public static void Param_NegativeNumberOfPaymentPeriods_Exception()
        {
            decimal rate = 0.5M;
            int numberOfPeriods = -10;
            decimal presentValue = 450M;

            string expected = "The argument cannot be less than or equal to 0.\nParameter name: numberOfPaymentPeriods";
            string actual = "";

            try
            {
                decimal target = Financial.GetPayment(rate, numberOfPeriods, presentValue);
            }
            catch (ArgumentOutOfRangeException exception)
            {
                actual = exception.Message;
            }

            Console.Write("Expected: {0}\nActual: {1}\n\n\n", expected, actual);
        }

        public static void Param_NumberOfPaymentPeriodsZero_Exception()
        {
            decimal rate = 0.5M;
            int numberOfPeriods = 0;
            decimal presentValue = 450M;

            string expected = "The argument cannot be less than or equal to 0.\nParameter name: numberOfPaymentPeriods";
            string actual = "";

            try
            {
                decimal target = Financial.GetPayment(rate, numberOfPeriods, presentValue);
            }
            catch (ArgumentOutOfRangeException exception)
            {
                actual = exception.Message;
            }

            Console.Write("Expected: {0}\nActual: {1}\n\n\n", expected, actual);
        }

        public static void Param_NegativePresentValue_Exception()
        {
            decimal rate = 0.5M;
            int numberOfPeriods = 10;
            decimal presentValue = -450M;

            string expected = "The argument cannot be less than or equal to 0.\nParameter name: presentValue";
            string actual = "";

            try
            {
                decimal target = Financial.GetPayment(rate, numberOfPeriods, presentValue);
            }
            catch (ArgumentOutOfRangeException exception)
            {
                actual = exception.Message;
            }

            Console.Write("Expected: {0}\nActual: {1}\n\n\n", expected, actual);
        }

        public static void Param_PresentValueZero_Exception()
        {
            decimal rate = 0.5M;
            int numberOfPeriods = 10;
            decimal presentValue = 0M;

            string expected = "The argument cannot be less than or equal to 0.\nParameter name: presentValue";
            string actual = "";

            try
            {
                decimal target = Financial.GetPayment(rate, numberOfPeriods, presentValue);
            }
            catch (ArgumentOutOfRangeException exception)
            {
                actual = exception.Message;
            }

            Console.Write("Expected: {0}\nActual: {1}\n\n\n", expected, actual);
        }

        public static void Successful_Value_Calculated()
        {
            decimal rate = 0.5M;
            int numberOfPeriods = 10;
            decimal presentValue = 450M;
           
            decimal target = Financial.GetPayment(rate, numberOfPeriods, presentValue);
          
            decimal expected = 228.97M;
            decimal actual = target;

            Console.Write("Expected: {0:0.00}\nActual: {1:0.00}\n\n\n", expected, actual);
        }
    }
}

