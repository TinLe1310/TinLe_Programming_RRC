/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created:   2022-01-31
 * Updated:   2022-01-31
 */

// Quest 5.14.7.51
import java.util.Scanner;
public class Quest4
{
    public static void main(String[] args)
    {
        //Input a year number from keyboard
        Scanner keyboard = new Scanner(System.in);
        String year = "";
        int yearNumber;
        final int TWO_DIGIT_YEAR = 2;
        final int FOUR_DIGIT_YEAR = 4;

        System.out.printf("Please enter a 2-digit or 4-digit year: ");
        year = keyboard.nextLine();

        //Evaluating and outout the year
        if (year.length() == TWO_DIGIT_YEAR)
        {
            yearNumber = Integer.parseInt(year);
            yearNumber += 2000;
            System.out.printf("The year entered is %d.\n",yearNumber);
        }
        else if (year.length() == FOUR_DIGIT_YEAR)
        {
            yearNumber = Integer.parseInt(year);
            System.out.printf("The year entered is %d.\n",yearNumber);
        }
        else
        {
            System.out.printf("You entered an invalid year.\n");
        }
    }
}