/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created:   2022-01-31
 * Updated:   2022-01-31
 */

// Quest 5.14.7.50
import java.util.Scanner;
public class Quest3
{
    public static void main(String[] args)
    {
        //Input a temperature from keyboard
        Scanner keyboard = new Scanner(System.in);
        int temperature;

        System.out.printf("Enter a temperature: ");
        temperature = keyboard.nextInt();

        //Deciding the season by the temperature
        if (temperature > 110 || temperature < -5)
        {
            System.out.printf("The temperature is out of range.\n");
        }
        else if (temperature >= 90)
        {
            System.out.printf("The season is summer.\n");
        }
        else if (temperature >= 70)
        {
             System.out.printf("The season is spring.\n");
        }
        else if (temperature >= 50)
        {
            System.out.printf("The season is fall.\n");
        }
        else
        {
           System.out.printf("The season is winter.\n");
        }
    }
}