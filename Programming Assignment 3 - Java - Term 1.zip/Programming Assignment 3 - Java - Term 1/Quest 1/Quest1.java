/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created:   2022-01-31
 * Updated:   2022-01-31
 */

// Quest 5.14.6.45
import java.util.Scanner;
public class Quest1
{
    public static void main(String[] args)
    {
        // Input a sentence.
        Scanner keyboard = new Scanner(System.in);
        String completeSentence = "";
        String symbol = "";
        String result = "";
        int position;

        System.out.printf("Please enter a sentence complete with punctuation: \n");
        completeSentence = keyboard.nextLine();

        System.out.printf("\n");

        // Evaluating the sentence through last character.
        position = completeSentence.length() - 1;
        symbol = "" + completeSentence.charAt(position);
        switch(symbol)
        {
            case ".":
                result = "declarative";
                break;
            case "?":
                result = "interrogative";
                break;
            case "!":
                result = "exclamatory";
                break;
            default:
                result = "other type";
       }
       System.out.printf("The sentence is %s.\n",result);
    }
}