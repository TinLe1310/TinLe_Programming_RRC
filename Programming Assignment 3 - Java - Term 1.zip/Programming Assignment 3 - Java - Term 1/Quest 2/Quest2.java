/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created:   2022-01-31
 * Updated:   2022-01-31
 */

 // Quest 5.14.6.47
 import java.util.Scanner;
 public class Quest2
 {
     public static void main(String[] args)
     {
         //Input a password from keyboard
         Scanner keyboard = new Scanner(System.in);
         String firstPass;
         String secondPass;

         System.out.printf("Please enter your password: ");
         firstPass = keyboard.nextLine();
         System.out.printf("\n");

         //Input a password again
         System.out.printf("Please repeat your password: ");
         secondPass = keyboard.nextLine();
         System.out.printf("\n");

         //Comparing 2 password and concluding the final result
         String acceptResult = "You are now registered as a new user.";
         String nonAcceptResult = "Sorry, there is a typo in your password.";
         String finalResult = firstPass.compareTo(secondPass) == 0 ? acceptResult : nonAcceptResult;
         System.out.printf("%s\n",finalResult);
     }
 }