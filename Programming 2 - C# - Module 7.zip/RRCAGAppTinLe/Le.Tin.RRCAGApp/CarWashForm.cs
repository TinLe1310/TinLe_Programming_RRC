﻿using ACE.BIT.ADEV.CarWash;
using ACE.BIT.ADEV.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Le.Tin.Business;

namespace Le.Tin.RRCAGApp
{
    public partial class CarWashForm : ACE.BIT.ADEV.Forms.CarWashForm
    {
        private string selectedFragrance;

        private BindingList<Package> packages;
        private BindingSource packagesSource;
        private List<CarWashItem> initialFragrances;
        private BindingList<CarWashItem> fragrances;
        private BindingSource fragrancesSource;
        private BindingList<string> interior;
        private BindingSource interiorServiceSource;
        private BindingList<string> exterior;
        private BindingSource exteriorServiceSource;
        private CarWashInvoice carWashInvoice;
        private BindingSource carWashInvoiceSource;

        public CarWashForm()
        {

            InitializeComponent();

            this.Load += CarWashForm_Load;

            // Package objects for data binding
            this.packages = new BindingList<Package>();
            this.packages.Add(InitializePackage("Standard"));
            this.packages.Add(InitializePackage("Deluxe"));
            this.packages.Add(InitializePackage("Executive"));
            this.packages.Add(InitializePackage("Luxury"));
            this.packagesSource = new BindingSource();
            this.packagesSource.DataSource = this.packages;

            // Fragrance objects for data binding
            this.initialFragrances = new List<CarWashItem>();
            this.fragrances = new BindingList<CarWashItem>();

            InitializeFragrance();          
            CarWashItem pineItem = new CarWashItem("Pine", 0m);  
            this.initialFragrances.Add(pineItem);
            this.initialFragrances.Sort();

            for (int i = 0; i < initialFragrances.Count; i++)
            {
                this.fragrances.Add(initialFragrances[i]);
            }

            this.fragrancesSource = new BindingSource();
            this.fragrancesSource.DataSource = this.fragrances;

            // Interior Service object for data binding
            this.interior = new BindingList<string>() ;
            this.interiorServiceSource = new BindingSource(); 
            this.interiorServiceSource.DataSource = typeof(string);

            // Exterior Service object for data binding
            this.exterior = new BindingList<string>();
            this.exteriorServiceSource = new BindingSource();
            this.exteriorServiceSource.DataSource = typeof(string);

            // Car Wash Invoice object
            this.carWashInvoice = null;
            this.carWashInvoiceSource = new BindingSource();
            this.carWashInvoiceSource.DataSource = typeof(CarWashInvoice);

            BindingControl();

            this.cboPackage.SelectedIndexChanged += PackagesSource_SelectedIndexChanged;
            this.fragrancesSource.PositionChanged += FragrancesSource_PositionChanged;
            this.mnuFileClose.Click += MnuFileClose_Click;
            this.mnuToolsGenerateInvoice.Click += MnuToolsGenerateInvoice_Click;

        }


        /// <summary>
        /// Handles the Click event of mnuToolsGenerateInvoice
        /// </summary>
        private void MnuToolsGenerateInvoice_Click(object sender, EventArgs e)
        {
            CarWashInvoiceForm form = new CarWashInvoiceForm(this.carWashInvoice);
            form.ShowDialog();
            ClearForm();
        }

        /// <summary>
        /// Handles the Click event of the mnuFileCLose
        /// </summary>
        private void MnuFileClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Handles the Position changed event of the FragrancesSource
        /// </summary>
        private void FragrancesSource_PositionChanged(object sender, EventArgs e)
        {
            if (this.cboPackage.SelectedIndex != -1)
            {
                this.selectedFragrance = this.fragrancesSource.Current.ToString();
                Updating_InteriorList();
            }
        }

        /// <summary>
        /// Handles the Selected index changed event of the PackagesSource
        /// </summary>
        private void PackagesSource_SelectedIndexChanged(object sender, EventArgs e)
        {
            Package package = (Package)this.cboPackage.SelectedItem;
            this.cboPackage.ValueMember = "price";

            CarWashItem fragrance = (CarWashItem)this.cboFragrance.SelectedItem;
            this.cboFragrance.ValueMember = "price";

            if (this.cboPackage.SelectedIndex != -1)
            {
                Updating_InteriorList();
            }

            this.mnuToolsGenerateInvoice.Enabled = true;
            this.mnuFileClose.Enabled = true;
        }

        /// <summary>
        /// Handles the Load event of the form
        /// </summary>
        private void CarWashForm_Load(object sender, EventArgs e)
        {
           ClearForm();
        }

        /// <summary>
        /// Binding data
        /// </summary>
        private void BindingControl()
        {
            // Package
            this.cboPackage.DataSource = this.packagesSource;
            this.cboPackage.DisplayMember = "description";

            // Fragrance
            this.cboFragrance.DataSource = this.fragrancesSource;
            this.cboFragrance.DisplayMember = "description";

            // Interior
            this.lstInterior.DataSource = this.interiorServiceSource;

            // Exterior
            this.lstExterior.DataSource = this.exteriorServiceSource;

            // Calculation CarWashInvoice
            Binding subTotalBind = new Binding("Text", this.carWashInvoiceSource, "SubTotal");
            subTotalBind.FormattingEnabled = true;
            subTotalBind.FormatString = "c";
            this.lblSubtotal.DataBindings.Add(subTotalBind);

            Binding PSTBind = new Binding("Text", this.carWashInvoiceSource, "ProvincialSalesTaxCharged");
            PSTBind.FormattingEnabled = true;   
            PSTBind.FormatString = "N2";
            this.lblProvincialSalesTax.DataBindings.Add(PSTBind);

            Binding GSTBind = new Binding("Text", this.carWashInvoiceSource, "GoodsAndServicesTaxCharged");
            GSTBind.FormattingEnabled = true;
            GSTBind.FormatString = "N2";
            this.lblGoodsAndServicesTax.DataBindings.Add(GSTBind);

            Binding totalBind = new Binding("Text", this.carWashInvoiceSource, "Total");
            totalBind.FormattingEnabled = true;
            totalBind.FormatString = "c";
            this.lblTotal.DataBindings.Add(totalBind);
        }

        /// <summary>
        /// Return the form to its initial state method
        /// </summary>
        private void ClearForm()
        {
            this.cboPackage.SelectedIndex = -1;
            this.cboFragrance.SelectedIndex = 4;
            this.mnuToolsGenerateInvoice.Enabled = false;
            this.interior.Clear();
            this.exterior.Clear();
            this.lblSubtotal.Text = string.Empty;
            this.lblProvincialSalesTax.Text = string.Empty;
            this.lblGoodsAndServicesTax.Text = string.Empty;
            this.lblTotal.Text = string.Empty;
        }

        /// <summary>
        /// Update the interior list method
        /// </summary>
        private void Updating_InteriorList()
        {
            Package package = (Package)this.cboPackage.SelectedItem;
           
            this.interior.Clear();
            this.exterior.Clear();

            for (int i = 0; i < package.ExteriorServices.Count; i++)
            {
                this.interior.Add(package.InteriorServices[i]);
                this.exterior.Add(package.ExteriorServices[i]);
            }
            Calculate_CarWashInvoice();
            this.interiorServiceSource.DataSource = this.interior;
            this.exteriorServiceSource.DataSource = this.exterior;
            this.selectedFragrance = this.fragrancesSource.Current.ToString();
            this.interior[0] += selectedFragrance;
        }

        /// <summary>
        /// Calculation for SubTotal, PST, GST and Total method
        /// </summary>
        private void Calculate_CarWashInvoice()
        {
            decimal packageCost = decimal.Parse(this.cboPackage.SelectedValue.ToString());
            decimal fragranceCost = decimal.Parse(this.cboFragrance.SelectedValue.ToString());
            this.carWashInvoice = new CarWashInvoice(0.05m, 0.07m, packageCost, fragranceCost);
            this.carWashInvoiceSource.DataSource = this.carWashInvoice;
        }

        /// <summary>
        /// Initialize a package instance method
        /// </summary>
        private Package InitializePackage(string package)
        {
            Package packageChoice = null;

            switch (package)
            {
                case "Standard":
                    packageChoice = new Package(package, 7.5m, InteriorServiceChoice(package), ExteriorServiceChoice(package));
                    break;
                case "Deluxe":
                    packageChoice = new Package(package, 15m, InteriorServiceChoice(package), ExteriorServiceChoice(package));
                    break;
                case "Executive":
                    packageChoice = new Package(package, 35m, InteriorServiceChoice(package), ExteriorServiceChoice(package));
                    break;
                case "Luxury":
                    packageChoice = new Package(package, 55m, InteriorServiceChoice(package), ExteriorServiceChoice(package));
                    break;
            }

            return packageChoice;
        }

        /// <summary>
        /// Initialize a fragrance instance method
        /// </summary>
        private void InitializeFragrance()
        {
            try
            {
                string filepath = "fragrances.txt";
                FileStream fileStream = new FileStream(filepath, FileMode.Open, FileAccess.Read);
                StreamReader fileReader = new StreamReader(fileStream);

                while (fileReader.Peek() != -1)
                {
                    string record = fileReader.ReadLine();
                    char[] delimiters = { ',' };
                    string[] fields = record.Split(delimiters);

                    string name = fields[0];
                    decimal value = decimal.Parse(fields[1]);

                    CarWashItem fragrance = new CarWashItem(name, value);

                    this.initialFragrances.Add(fragrance);
                }
            }
            catch (IOException)
            {
                MessageBox.Show("Fragrances data file not found.", "Data File Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
            catch (Exception)
            {
                MessageBox.Show("An error occurred while reading the data file", "Data File Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }

        /// <summary>
        /// Initialize an interior service method
        /// </summary>
        private List<string> InteriorServiceChoice(string type)
        {
            List<string> interiorService = new List<string> { "Fragrance - ", "Shampoo Carpets", "Shampoo Upholstery", "Interior Protection Coat" };
            List<string> result = new List<string>();
           
            switch (type)
            {
                case "Standard":
                    result = new List<string> { interiorService[0] };                    
                    break;
                case "Deluxe":
                    result = new List<string> { interiorService[0], interiorService[1] };                  
                    break;
                case "Executive":
                    result = new List<string> { interiorService[0], interiorService[1], interiorService[2] };                    
                    break;
                case "Luxury":
                    result = new List<string> { interiorService[0], interiorService[1], interiorService[2], interiorService[3] };                   
                    break;
            }

            return result;
        }

        /// <summary>
        /// Initialize exterior service method
        /// </summary>
        private List<string> ExteriorServiceChoice(string type)
        {
            List<string> result = new List<string>();
            List<string> exteriorService = new List<string> { "Hand Wash", "Hand Wax", "Wheel Polish", "Detail Engine Compartment" };

            switch (type)
            {
                case "Standard":
                    result = new List<string> { exteriorService[0] };
                    break;
                case "Deluxe":
                    result = new List<string> { exteriorService[0], exteriorService[1] };
                    break;
                case "Executive":
                    result = new List<string> { exteriorService[0], exteriorService[1], exteriorService[2] };
                    break;
                case "Luxury":
                    result = new List<string> { exteriorService[0], exteriorService[1], exteriorService[2], exteriorService[3] };
                    break;
            }

            return result;
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // lstExterior
            // 
            this.lstExterior.ItemHeight = 16;
            // 
            // lstInterior
            // 
            this.lstInterior.ItemHeight = 16;
            // 
            // CarWashForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.ClientSize = new System.Drawing.Size(527, 528);
            this.Name = "CarWashForm";
            this.Text = "Car Wash";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}
