﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Le.Tin.RRCAGApp
{
    class VehicleDataForm : ACE.BIT.ADEV.Forms.VehicleDataForm
    {
        private OleDbConnection connection;
        private OleDbDataAdapter adapter;
        private DataSet dataset;
        private BindingSource bindingSource;

        /// <summary>
        /// Initializes an instance of the VehicleDataForm class.
        /// </summary>
        public VehicleDataForm()
        {
            InitializeComponent();

            this.bindingSource = new BindingSource();
            this.Load += VehicleDataForm_Load;
        }

        /// <summary>
        /// Handles the Load event of this form.
        /// </summary>
        private void VehicleDataForm_Load(object sender, EventArgs e)
        {
            try
            {
                RetrieveDataFromTheDatabase();
            }
            catch(Exception)
            {
                MessageBox.Show("Unable to load vehicle data", 
                                "Data Load Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            BindControls();

            this.FormClosing += VehicleDataForm_FormClosing;
            this.mnuFileSave.Click += MnuFileSave_Click;
            this.mnuEditDelete.Click += MnuEditDelete_Click;
            this.mnuFileClose.Click += MnuFileClose_Click;
            this.dgvVehicles.SelectionChanged += DgvVehicles_SelectionChanged;
            this.dgvVehicles.CellValueChanged += DgvVehicles_CellValueChanged;
            this.adapter.RowUpdated += Adapter_RowUpdated;
        }

        /// <summary>
        /// Handles the RowUpdated event of this DataAdapter.
        /// </summary>
        private void Adapter_RowUpdated(object sender, OleDbRowUpdatedEventArgs e)
        {
            if (e.StatementType == StatementType.Insert)
            {
                OleDbCommand command = new OleDbCommand("SELECT @@IDENTITY", connection);
                e.Row["ID"] = command.ExecuteScalar();
                e.Row["SoldBy"] = 0;            
            }
        }

        /// <summary>
        /// Handles the FormClosing event of this form.
        /// </summary>
        private void VehicleDataForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (this.Text != "Vehicle Data")
                {
                    DialogResult dialogResult = MessageBox.Show("Do you wish to save the changes?",
                                                                "Save",
                                                                MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning,
                                                                MessageBoxDefaultButton.Button3);
                    switch (dialogResult)
                    {
                        case DialogResult.Yes:
                            UpdateDataTable();
                            break;
                        case DialogResult.No:
                            connection.Close();
                            connection.Dispose();
                            break;
                        default:
                            e.Cancel = true;
                            break;
                    }
                }
            }
            catch(Exception)
            {
                DialogResult dialogResult = MessageBox.Show("An error occurred while saving the changes. Do you still wish to close?",
                                                            "Save Error",
                                                            MessageBoxButtons.YesNo, MessageBoxIcon.Error,
                                                            MessageBoxDefaultButton.Button2);
                if (dialogResult == DialogResult.No)
                {
                    e.Cancel = true;
                }
            }    
        }

        /// <summary>
        /// Queries the database and populates a dataset.
        /// </summary>
        private void RetrieveDataFromTheDatabase()
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=AMDatabase.mdb;";
            connection = new OleDbConnection(connectionString);
            connection.Open();

            OleDbCommand command = connection.CreateCommand();
            command.CommandText = "SELECT * FROM VehicleStock";

            adapter = new OleDbDataAdapter(command);

            dataset = new DataSet();
            adapter.Fill(dataset, "Stocks");

            OleDbCommandBuilder commandBuilder = new OleDbCommandBuilder(adapter);
            commandBuilder.ConflictOption = ConflictOption.OverwriteChanges;

            commandBuilder.GetInsertCommand();
            commandBuilder.GetDeleteCommand();
            commandBuilder.GetUpdateCommand();
        }

        /// <summary>
        /// Binds the controls on the form.
        /// </summary>
        private void BindControls()
        {
            bindingSource.DataSource = dataset.Tables[0];
            this.dgvVehicles.DataSource = bindingSource;
            this.dgvVehicles.Columns["ID"].Visible = false;
            this.dgvVehicles.Columns["SoldBy"].Visible = false;
        }

        /// <summary>
        /// Handles the CellValueChanged event of this form.
        /// </summary>
        private void DgvVehicles_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            this.bindingSource.EndEdit();
            this.Text = "* Vehicle Data";
            this.mnuFileSave.Enabled = true;
        }

        /// <summary>
        /// Handles the SelectionChanged event of this form.
        /// </summary>
        private void DgvVehicles_SelectionChanged(object sender, EventArgs e)
        {
            if (this.dgvVehicles.SelectedRows.Count == 1)
            {
                DataGridViewRow selectedRow = this.dgvVehicles.SelectedRows[0];

                if (selectedRow == this.dgvVehicles.CurrentRow && !selectedRow.IsNewRow)
                {
                    this.mnuEditDelete.Enabled = true;
                }
                else
                {
                    this.mnuEditDelete.Enabled = false;
                }
            }
            else
            {
                this.mnuEditDelete.Enabled = false;
            }
        }

        /// <summary>
        /// Handlers the Click event of the Save menu item.
        /// </summary>
        private void MnuFileSave_Click(object sender, EventArgs e)
        {
            try
            {
                UpdateDataTable();
            }
            catch(Exception)
            {
                MessageBox.Show("An error occurred while saving the changes to the vehicle data.",
                                "Save Error", 
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Text = "Vehicle Data";
            this.mnuFileSave.Enabled = false;
        }

        /// <summary>
        /// Handlers the Click event of the Delete menu item.
        /// </summary>
        private void MnuEditDelete_Click(object sender, EventArgs e)
        {
            DataGridViewRow row = this.dgvVehicles.SelectedRows[0];

            DialogResult dialogResult = MessageBox.Show($"Are you sure you want to permanently delete stock item {row.Cells[1].Value}?",
                                                        "Delete Stock Item", 
                                                        MessageBoxButtons.YesNo, 
                                                        MessageBoxIcon.Warning, 
                                                        MessageBoxDefaultButton.Button2);
            if (dialogResult == DialogResult.Yes)
            {
                this.dgvVehicles.Rows.Remove(row);
                try
                {
                    UpdateDataTable();
                }
                catch(Exception)
                {
                    MessageBox.Show("An error occurred while deleting the selected vehicle.",
                                    "Deletion Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                this.Text = "Vehicle Data";
                this.mnuEditDelete.Enabled = false;
            }
        }

        /// <summary>
        /// Handles the Click event of the Close menu item.
        /// </summary>
        private void MnuFileClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Method allow user to update the form through DataAdapter
        private void UpdateDataTable()
        {
            adapter.Update(dataset, "Stocks");
            dgvVehicles.EndEdit();
            bindingSource.EndEdit();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // VehicleDataForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.ClientSize = new System.Drawing.Size(949, 518);
            this.Name = "VehicleDataForm";
            this.Text = "Vehicle Data";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
