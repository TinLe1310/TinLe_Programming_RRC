﻿/*
 * Name: Tin Le
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-09-01
 * Updated: 2022-09-16
 */

namespace Le.Tin.Business
{
    ///<summary>
    /// This class contains functionality that supports the business process of determining a quote for the sale of a vehicle.
    ///</summary>
    class SalesQuote
    {
        private decimal vehicleSalePrice;
        private decimal tradeInAmount;
        private decimal salesTaxRate;
        private Accessories accessoriesChosen;
        private ExteriorFinish exteriorFinishChosen;


        /// <summary>
        /// Initializes an instance of SalesQuote with a vehicle price, trade-in value,
        /// sales tax rate, accessories chosen and exterior finish chosen.
        /// </summary>
        /// <param name="vehicleSalePrice">The selling price of the vehicle being sold.</param>
        /// <param name="tradeInAmount">The amount offered to the customer for the trade in of their vehicle.</param>
        /// <param name="salesTaxRate">The tax rate applied to the sale of a vehicle.</param>
        /// <param name="accessoriesChosens">The value of the chosen accessories.</param>
        /// <param name="exteriorFinishChosen">The value of the chosen exterior finish.</param>      
        public SalesQuote (decimal vehicleSalePrice, decimal tradeInAmount, decimal salesTaxRate, Accessories accessoriesChosen, ExteriorFinish exteriorFinishChosen)
        {
            SetVehicleSalePrice(vehicleSalePrice);
            SetTradeInAmount(tradeInAmount);
            this.salesTaxRate = salesTaxRate;
            SetAccessoriesChosen(accessoriesChosen);
            SetExteriorFinishChosen(exteriorFinishChosen);
        }

        /// <summary>
        /// Initializes an instance of SalesQuote with a vehicle price, trade-in value,
        /// sales tax rate, no accessories chosen and no exterior finish chosen.
        /// </summary>
        /// <param name="vehicleSalePrice">The selling price of the vehicle being sold.</param>
        /// <param name="tradeInAmount">The amount offered to the customer for the trade in of their vehicle.</param>
        /// <param name="salesTaxRate">The tax rate applied to the sale of a vehicle.</param>
        public SalesQuote (decimal vehicleSalePrice, decimal tradeInAmount, decimal salesTaxRate)
            : this(vehicleSalePrice, tradeInAmount, salesTaxRate, Accessories.None, ExteriorFinish.None)
        {
            // This constructor invokes the other constructor.
        }

        /// <summary>
        /// Gets the sale price of the vehicle.
        /// </summary>
        public decimal GetVehicleSalePrice()
        {
            return this.vehicleSalePrice;
        }

        /// <summary>
        /// Sets the sale price of the vehicle.
        /// </summary>
        /// <param name="vehicleSalePrice">The selling price of the vehicle being sold.</param>
        public void SetVehicleSalePrice(decimal vehicleSalePrice)
        {
            this.vehicleSalePrice = vehicleSalePrice;
        }

        /// <summary>
        /// Gets the trade in amount.
        /// </summary>
        public decimal GetTradeInAmount()
        {
            return this.tradeInAmount;
        }

        /// <summary>
        /// Sets the trade in amount.
        /// </summary>
        /// <param name="tradeInAmount">The amount offered to the customer for the trade in of their vehicle.</param>
        public void SetTradeInAmount(decimal tradeInAmount)
        {
            this.tradeInAmount = tradeInAmount;
        }

        /// <summary>
        /// Gets the accessories chosen for the vehicle.
        /// </summary>       
        public Accessories GetAccessoriesChosen()
        {
            return this.accessoriesChosen;
        }

        /// <summary>
        /// Sets the accessories chosen for the vehicle.
        /// </summary>  
        /// <param name="accessoriesChosens">The value of the chosen accessories.</param>       
        public void SetAccessoriesChosen(Accessories accessoriesChosen)
        {
            this.accessoriesChosen = accessoriesChosen;
        }

        /// <summary>
        /// Gets the exterior finish chosen for the vehicle.
        /// </summary>         
        public ExteriorFinish GetExteriorFinishChosen()
        {
            return this.exteriorFinishChosen;
        }

        /// <summary>
        /// Sets the accessories chosen for the vehicle.
        /// </summary>  
        /// <param name="exteriorFinishChosen">The value of the chosen exterior finish.</param>        
        public void SetExteriorFinishChosen(ExteriorFinish exteriorFinishChosen)
        {
            this.exteriorFinishChosen = exteriorFinishChosen;
        }

        /// <summary>
        /// Returns the cost of the accessories chosen.
        /// </summary>         
        public decimal GetAccessoriesCost()
        {
            decimal stereoSystem = 505.05M;
            decimal leatherInterior = 1010.10M;
            decimal computerNavigation = 1515.15M;
            decimal accessoriesCost = 0M;

            switch (GetAccessoriesChosen())
            {
                case Accessories.StereoSystem:
                    accessoriesCost = stereoSystem;
                    break;
                case Accessories.LeatherInterior:
                    accessoriesCost = leatherInterior;
                    break;
                case Accessories.StereoAndLeather:
                    accessoriesCost = stereoSystem + leatherInterior;
                    break;
                case Accessories.ComputerNavigation:
                    accessoriesCost = computerNavigation;
                    break;
                case Accessories.StereoAndNavigation:
                    accessoriesCost = stereoSystem + computerNavigation;
                    break;
                case Accessories.LeatherAndNavigation:
                    accessoriesCost = leatherInterior + computerNavigation;
                    break;
                case Accessories.All:
                    accessoriesCost = stereoSystem + leatherInterior + computerNavigation;
                    break;
                default:
                    break;
            }

            return accessoriesCost;
        }

        /// <summary>
        /// Returns the cost of the exterior finish chosen.
        /// </summary>      
        public decimal GetExteriorFinishCost()
        {
            decimal standard = 202.02M;
            decimal pearlized = 404.04M;
            decimal custom = 606.06M;
            decimal exteriorFinishCost = 0M;

            switch (GetExteriorFinishChosen())
            {
                case ExteriorFinish.Standard:
                    exteriorFinishCost = standard;
                    break;
                case ExteriorFinish.Pearlized:
                    exteriorFinishCost = pearlized;
                    break;
                case ExteriorFinish.Custom:
                    exteriorFinishCost = custom;
                    break;
                default:
                    break;
            }

            return exteriorFinishCost;
        }

        /// <summary>
        /// Return the sum of the cost of accessories chosen and the cost of the exterior finish chosen
        /// (rounded to two decimal places).
        /// </summary>       
        public decimal GetTotalOptions()
        {
            return decimal.Round(GetAccessoriesCost() + GetExteriorFinishCost(), 2);
        }

        /// <summary>
        /// Returns the sum of the vehicle’s sale price, accessories and exterior finish costs
        /// (rounded to two decimal places).
        /// </summary>       
        public decimal GetSubTotal()
        {
            return decimal.Round(this.vehicleSalePrice + GetTotalOptions(), 2);
        }

        /// <summary>
        /// Returns the amount of tax to charge based on the subtotal
        /// (rounded to two decimal places).
        /// </summary>       
        public decimal GetSalesTax()
        {
            return decimal.Round(this.salesTaxRate * GetSubTotal(), 2);
        }

        /// <summary>
        /// Returns the sum of the subtotal and taxes.
        /// </summary>       
        public decimal GetTotal()
        {
            return GetSalesTax() + GetSubTotal();
        }

        /// <summary>
        /// Returns the difference of the total and trade-in amount 
        /// (rounded to two decimal places).
        /// </summary>
        public decimal GetAmountDue()
        {
            return decimal.Round(GetTotal() - this.tradeInAmount, 2);
        }
    }
}