﻿/*
 * Name: Tin Le
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-09-01
 * Updated: 2022-09-16
 */

namespace Le.Tin.Business
{
    /// <summary>
    /// The Accessories enumeration has the following values 
    /// </summary>
    public enum Accessories
    {
        /// <summary>
        /// StereoSystem - The stereo system accessory.
        /// </summary>
        StereoSystem = 0,
        
        /// <summary>
        /// LeatherInterior - The leather interior accessory.
        /// </summary>
        LeatherInterior = 1,
        
        /// <summary>
        /// StereoAndLeather - The stereo system and leather interior accessories.
        /// </summary>
        StereoAndLeather = 2,
        
        /// <summary>
        /// ComputerNavigation - The computer navigation accessory.
        /// </summary>
        ComputerNavigation = 3,
        
        /// <summary>
        /// StereoAndNavigation - The stereo system and computer navigation accessories.
        /// </summary>
        StereoAndNavigation = 4,
        
        /// <summary>
        /// LeatherAndNavigation - The leather interior and computer navigation accessories.
        /// </summary>
        LeatherAndNavigation = 5,

        /// <summary>
        /// All - All the accessories.
        /// </summary>
        All = 6,

        /// <summary>
        /// None - None of the accessories.
        /// </summary>
        None = 7
    }
}