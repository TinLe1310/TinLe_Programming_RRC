﻿/*
 * Name: Tin Le
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-09-01
 * Updated: 2022-09-16
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Le.Tin.Business;

namespace Le.Tin.RRCAG
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Testing - Constructor SalesQuote(decimal, decimal, decimal)");          
            Console.WriteLine("Test #1 using GetVehicleSalePrice() method");
            Constructor_VehicleSalePrice_Initialize();

            Console.WriteLine("Test #2 using GetTradeInAmount() method");
            Constructor_TradeInAmount_Initialize();

            Console.WriteLine("Test #3 using GetSalesTax() method");
            Constructor_SalesTaxRate_Initialize();

            Console.WriteLine("Test #4 using GetAccessoriesChosen() method");
            Constructor_Accessories_Initialize();
            
            Console.WriteLine("Test #5 using GetExteriorFinishChosen() method");
            Constructor_ExtoriorFinish_Initialize();

            Console.WriteLine("Testing - Method SetTradeInAmount(decimal) : void");          
            Console.WriteLine("Test #1 Update trade in amount");
            Update_TradeInAmount_State();

            Console.WriteLine("Testing - Method GetExteriorFinishCost() : decimal");
            Console.WriteLine("Test #1 Return exterior finish cost: Standard");
            Return_ExteriorFinishCost_Standard();

            Console.WriteLine("Test #2 Return exterior finish cost: Pearlized");
            Return_ExteriorFinishCost_Pearlized();

            Console.WriteLine("Test #3 Return exterior finish cost: Custom");
            Return_ExteriorFinishCost_Custom();

            Console.WriteLine("Test #4 Return exterior finish cost: None");
            Return_ExteriorFinishCost_None();

            Console.WriteLine("Testing - Method GetTotal() : decimal");
            Console.WriteLine("Test #1 Return the total cost");
            Return_TotalCost();

            Console.ReadKey();
        }

        /*
         * Constructor - GraduateApplicant(String, String, String)
         */
        public static void Constructor_VehicleSalePrice_Initialize()
        {
            decimal vehicleSalePrice = 5000M;
            decimal tradeInAmount = 3000M;
            decimal salesTaxRate = 0.15M;

            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);

            decimal expected = 5000M;
            decimal actual = target.GetVehicleSalePrice();

            Console.Write("Expected: {0:C2}\nActual: {1:C2}\n\n", expected, actual);
        }

        public static void Constructor_TradeInAmount_Initialize()
        {
            decimal vehicleSalePrice = 5000M;
            decimal tradeInAmount = 3000M;
            decimal salesTaxRate = 0.15M;

            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);

            decimal expected = 3000M;
            decimal actual = target.GetTradeInAmount();

            Console.Write("Expected: {0:C2}\nActual: {1:C2}\n\n", expected, actual);
        }

        public static void Constructor_SalesTaxRate_Initialize()
        {
            decimal vehicleSalePrice = 5000M;
            decimal tradeInAmount = 3000M;
            decimal salesTaxRate = 0.15M;

            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);

            decimal expected = 750M;
            decimal actual = target.GetSalesTax();

            Console.Write("Expected: {0:C2}\nActual: {1:C2}\n\n", expected, actual);
        }

        public static void Constructor_Accessories_Initialize()
        {
            decimal vehicleSalePrice = 5000M;
            decimal tradeInAmount = 3000M;
            decimal salesTaxRate = 0.15M;

            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);

            string expected = "None";
            Accessories actual = target.GetAccessoriesChosen();

            Console.Write("Expected: {0}\nActual: {1}\n\n", expected, actual);
        }

        public static void Constructor_ExtoriorFinish_Initialize()
        {
            decimal vehicleSalePrice = 5000M;
            decimal tradeInAmount = 3000M;
            decimal salesTaxRate = 0.15M;

            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);

            string expected = "None";
            ExteriorFinish actual = target.GetExteriorFinishChosen();

            Console.Write("Expected: {0}\nActual: {1}\n\n", expected, actual);
        }

        /*
         * Method SetTradeInAmount(decimal) : void
         */
        public static void Update_TradeInAmount_State()
        {
            decimal vehicleSalePrice = 5000M;
            decimal tradeInAmount = 3000M;
            decimal salesTaxRate = 0.15M;

            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);
            target.SetTradeInAmount(4000M);
            
            decimal expected = 4000M;
            decimal actual = target.GetTradeInAmount();

            Console.Write("Expected: {0:C2}\nActual: {1:C2}\n\n", expected, actual);
        }

        /*
         * Method GetExteriorFinishCost() : decimal
         */
        public static void Return_ExteriorFinishCost_Standard()
        {
            decimal vehicleSalePrice = 5000M;
            decimal tradeInAmount = 3000M;
            decimal salesTaxRate = 0.15M;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);

            decimal expected = 202.02M;
            decimal actual = target.GetExteriorFinishCost();

            Console.Write("Expected: {0:C2}\nActual: {1:C2}\n\n", expected, actual);
        }

        public static void Return_ExteriorFinishCost_Pearlized()
        {
            decimal vehicleSalePrice = 5000M;
            decimal tradeInAmount = 3000M;
            decimal salesTaxRate = 0.15M;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Pearlized;

            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);

            decimal expected = 404.04M;
            decimal actual = target.GetExteriorFinishCost();

            Console.Write("Expected: {0:C2}\nActual: {1:C2}\n\n", expected, actual);
        }

        public static void Return_ExteriorFinishCost_Custom()
        {
            decimal vehicleSalePrice = 5000M;
            decimal tradeInAmount = 3000M;
            decimal salesTaxRate = 0.15M;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Custom;

            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);

            decimal expected = 606.06M;
            decimal actual = target.GetExteriorFinishCost();

            Console.Write("Expected: {0:C2}\nActual: {1:C2}\n\n", expected, actual);
        }

        public static void Return_ExteriorFinishCost_None()
        {
            decimal vehicleSalePrice = 5000M;
            decimal tradeInAmount = 3000M;
            decimal salesTaxRate = 0.15M;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.None;

            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);

            decimal expected = 0M;
            decimal actual = target.GetExteriorFinishCost();

            Console.Write("Expected: {0:C2}\nActual: {1:C2}\n\n", expected, actual);
        }

        /*
         * Method GetTotal() : decimal
         */
        public static void Return_TotalCost()
        {
            decimal vehicleSalePrice = 5000M;
            decimal tradeInAmount = 3000M;
            decimal salesTaxRate = 0.15M;

            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);

            decimal expected = 5750M;
            decimal actual = target.GetTotal();

            Console.Write("Expected: {0:C2}\nActual: {1:C2}\n\n", expected, actual);
        }
    }
}