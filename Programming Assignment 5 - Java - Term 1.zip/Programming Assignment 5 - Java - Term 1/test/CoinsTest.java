/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created:   2022-02-20
 * Updated:   2022-02-20
 */

/**
 * A program to test the Coins class
 *
 *@author Tin Le
 *@version 1.0
 */
 public class CoinsTest
 {
     public static void main(String[] args)
     {
         System.out.println("Coins(int, int, int)");
         System.out.println("Test #1 - Initialize the number of quarters");
         constructor1_quarters_initialize();

         System.out.println("Test #2 - Initialize the number of dimes");
         constructor1_dimes_initialize();

         System.out.println("Test #3 - Initialize the number of nickels");
         constructor1_nickels_initialize();

         System.out.println("Coins()");
         System.out.println("Test #1 - Initialize the number of quarters");
         constructor2_quarters_initialize();

         System.out.println("Test #2 - Initialize the number of dimes");
         constructor2_dimes_initialize();

         System.out.println("Test #3 - Initialize the number of nickels");
         constructor2_nickels_initialize();

         System.out.println("setQuarters(int)");
         System.out.println("Test #1 - Update state of quarters");
         setQuarters_quarters_updateState();

         System.out.println("setDimes(int)");
         System.out.println("Test #1 - Update state of dimes");
         setDimes_dimes_updateState();

         System.out.println("setNickels(int)");
         System.out.println("Test #1 - Update state of nickels");
         setNickels_nickels_updateState();

         System.out.println("getDollarAmount()");
         System.out.println("Test #1 - Returns the correct dollar amount");
         getDollarAmount_correctAmount();

         System.out.println("getDollarAmount(CoinType type)");
         System.out.println("Test #1 - Returns the correct dollar amount for the quarters CoinType");
         getDollarAmount_quarters_correctAmount();

         System.out.println("Test #2 - Returns the correct dollar amount for the dimes CoinType");
         getDollarAmount_dimes_correctAmount();

         System.out.println("Test #3 - Returns the correct dollar amount for the nickels CoinType");
         getDollarAmount_nickels_correctAmount();

         System.out.println("getDollarAmount(int,int,int)");
         System.out.println("Test #1 - Returns the correct dollar amount");
         getDollarAmount_specified_correctAmount();

         System.out.println("toString()");
         System.out.println("Test #1 - Returns the correct String representation");
         toString_correctRepresentation();
     }

     /*
      * Constructor1 - Coins(int, int, int)
      */
      public static void constructor1_quarters_initialize()
      {
          int quarters = 5;
          int dimes = 6;
          int nickels = 8;

          Coins target = new Coins(quarters, dimes, nickels);

          int expect = 5;
          int actual = target.getQuarters();

          System.out.printf("Expected: %d\nActual: %d\n\n",expect,actual);
      }

      public static void constructor1_dimes_initialize()
      {
          int quarters = 5;
          int dimes = 6;
          int nickels = 8;

          Coins target = new Coins(quarters, dimes, nickels);

          int expect = 6;
          int actual = target.getDimes();

          System.out.printf("Expected: %d\nActual: %d\n\n",expect,actual);
      }

      public static void constructor1_nickels_initialize()
      {
          int quarters = 5;
          int dimes = 6;
          int nickels = 8;

          Coins target = new Coins(quarters, dimes, nickels);

          int expect = 8;
          int actual = target.getNickels();

          System.out.printf("Expected: %d\nActual: %d\n\n",expect,actual);
      }

      /*
       * Constructor2 - Coins()
       */
       public static void constructor2_quarters_initialize()
       {
           Coins target = new Coins();

           int expect = 0;
           int actual = target.getQuarters();

           System.out.printf("Expected: %d\nActual: %d\n\n",expect,actual);
      }

       public static void constructor2_dimes_initialize()
       {
           Coins target = new Coins();

           int expect = 0;
           int actual = target.getDimes();

           System.out.printf("Expected: %d\nActual: %d\n\n",expect,actual);
      }

       public static void constructor2_nickels_initialize()
       {
           Coins target = new Coins();

           int expect = 0;
           int actual = target.getNickels();

           System.out.printf("Expected: %d\nActual: %d\n\n",expect,actual);
      }

     /*
      * setQuarter(int)
      */
      public static void setQuarters_quarters_updateState()
      {
          int quarters = 5;
          int dimes = 6;
          int nickels = 8;

          Coins target = new Coins(quarters, dimes, nickels);

          target.setQuarters(10);

          int expect = 10;
          int actual = target.getQuarters();

          System.out.printf("Expected: %d\nActual: %d\n\n",expect,actual);
      }

      /*
       * setDimes(int)
       */
       public static void setDimes_dimes_updateState()
       {
           int quarters = 5;
           int dimes = 6;
           int nickels = 8;

           Coins target = new Coins(quarters, dimes, nickels);

           target.setDimes(7);

           int expect = 7;
           int actual = target.getDimes();

           System.out.printf("Expected: %d\nActual: %d\n\n",expect,actual);
      }

      /*
       * setNickels(int)
       */
       public static void setNickels_nickels_updateState()
       {
           int quarters = 5;
           int dimes = 6;
           int nickels = 8;

           Coins target = new Coins(quarters, dimes, nickels);

           target.setNickels(4);

           int expect = 4;
           int actual = target.getNickels();

           System.out.printf("Expected: %d\nActual: %d\n\n",expect,actual);
      }

      /*
       * getDollarAmount()
       */
       public static void getDollarAmount_correctAmount()
       {
           int quarters = 3;
           int dimes = 4;
           int nickels = 5;

           Coins target = new Coins(quarters, dimes, nickels);

           double expect = 1.4;
           double actual = target.getDollarAmount();

           System.out.printf("Expected: %f\nActual: %f\n\n",expect,actual);
      }

      /*
       * getDollarAmount(CoinType type)
       */
       public static void getDollarAmount_quarters_correctAmount()
       {
           int quarters = 3;
           int dimes = 4;
           int nickels = 5;

           Coins target = new Coins(quarters, dimes, nickels);

           double expect = 0.75;
           double actual = target.getDollarAmount(CoinType.QUARTER);

           System.out.printf("Expected: %f\nActual: %f\n\n",expect,actual);
       }

       public static void getDollarAmount_dimes_correctAmount()
       {
           int quarters = 3;
           int dimes = 4;
           int nickels = 5;

           Coins target = new Coins(quarters, dimes, nickels);

           double expect = 0.4;
           double actual = target.getDollarAmount(CoinType.DIME);

           System.out.printf("Expected: %f\nActual: %f\n\n",expect,actual);
      }

      public static void getDollarAmount_nickels_correctAmount()
      {
          int quarters = 3;
          int dimes = 4;
          int nickels = 5;

          Coins target = new Coins(quarters, dimes, nickels);

          double expect = 0.25;
          double actual = target.getDollarAmount(CoinType.NICKEL);

          System.out.printf("Expected: %f\nActual: %f\n\n",expect,actual);
      }

      /*
       * getDollarAmount(int,int,int)
       */
       public static void getDollarAmount_specified_correctAmount()
       {
           int quarters = 3;
           int dimes = 4;
           int nickels = 5;

           Coins target = new Coins(quarters, dimes, nickels);

           double expect = 1.1;
           double actual = target.getDollarAmount(1,5,7);

           System.out.printf("Expected: %f\nActual: %f\n\n",expect,actual);
       }

       /*
        * toString()
        */
        public static void toString_correctRepresentation()
        {
           int quarters = 8;
           int dimes = 9;
           int nickels = 11;

           Coins target = new Coins(quarters, dimes, nickels);

           System.out.printf("Expected:\nQuarters: 8\nDimes: 9\nNickels: 11\nTotal Value: $3.45\nActual: \n");
           System.out.println(target.toString());
        }
 }