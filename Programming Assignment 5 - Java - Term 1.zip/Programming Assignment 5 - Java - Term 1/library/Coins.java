/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created:   2022-02-20
 * Updated:   2022-02-20
 */

public class Coins
{
    private int quarters;
    private int dimes;
    private int nickels;

    private static double QUARTER = 0.25;
    private static double DIME = 0.1;
    private static double NICKEL = 0.05;

   /**
    * Initializes a new instance of the Coins class
    * with the specified number of coins for each coin type.
    *
    *@param quarters Number of quarters.
    *@param dimes Number of dimes.
    *@param nickels Number of nickels.
    */
    public Coins(int quarters, int dimes, int nickels)
    {
        setQuarters(quarters);
        setDimes(dimes);
        setNickels(nickels);
    }

    /**
     *
     */
     public Coins()
     {
         this(0, 0, 0);
     }

     /**
      * Returns the number of quarters.
      *
      *@return The number of quarters.
      */
      public int getQuarters()
      {
         return this.quarters;
      }

     /**
      * Returns the number of dimes.
      *
      *@return The number of dimes.
      */
      public int getDimes()
      {
         return this.dimes;
      }

     /**
      * Returns the number of nickels.
      *
      *@return The number of nickels.
      */
      public int getNickels()
      {
         return this.nickels;
      }

     /**
      * Sets the number of quarters.
      *
      *@param quarters The number of quarters.
      */
      public void setQuarters(int quarters)
      {
          this.quarters = quarters;
      }

     /**
      * Sets the number of dimes.
      *
      *@param dimes The number of dimes.
      */
      public void setDimes(int dimes)
      {
          this.dimes = dimes;
      }

     /**
      * Sets the number of nickels.
      *
      *@param nickels The number of nickels.
      */
      public void setNickels(int nickels)
      {
          this.nickels = nickels;
      }

     /**
      * Returns the combined dollar value of all coins.
      *
      *@return The dollar value.
      */
      public double getDollarAmount()
      {
          return this.quarters * QUARTER + this.dimes * DIME + this.nickels * NICKEL;
      }

     /**
      * Returns a double representing the dollar value of coins
      * based on the CoinType specified.
      *
      *@return The dollar value.
      */
      public double getDollarAmount(CoinType type)
      {
          double dollarValue = 0;
          switch(type.toString())
          {
              case "QUARTER":
                   dollarValue = this.quarters * QUARTER;
                   break;
              case "DIME":
                   dollarValue = this.dimes * DIME;
                   break;
              case "NICKEL":
                   dollarValue = this.nickels * NICKEL;
                   break;
          }
          return dollarValue;
      }

     /**
      * Returns a double representing the combined dollar value
      * of the specified number of coins for each coin type.
      *
      *@param quarters The number of quarters.
      *@param dimes The number of dimes.
      *@param nickels The number of nickels.
      *@return The dollar value.
      */
      public static double getDollarAmount(int quarters, int dimes, int nickels)
      {
          Coins newInstance = new Coins(quarters, dimes, nickels);
          return quarters * QUARTER + dimes * DIME + nickels * NICKEL;
      }

     /**
      * Returns the String representation of the class.
      *
      *@return A String representation of the class.
      */
      public String toString()
      {
          String template = "Quarters: %d\nDimes: %d\nNickels: %d\nTotal Value: $%f\n\n";
          return String.format(template, quarters, dimes, nickels, getDollarAmount());
      }
}
