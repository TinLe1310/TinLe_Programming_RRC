/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created:   2022-02-20
 * Updated:   2022-02-20
 */

/**
 * Represent the coin type
 *
 *@author Tin Le
 *@version 1.0
 */
public enum CoinType
{
    QUARTER,
    DIME,
    NICKEL
}
