/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created: 2022-01-21
 * Updated: 2022-01-21
 */

 // Quest 3.18.7.59
 import java.util.Random;
 public class Quest3
 {
     public static void main(String[] args)
     {
        // Generate 5 random number from 60 to 100
        Random randomGenerator = new Random();
        final int MAXIMUM = 100;
        final int MINIMUM = 60;
        int firstNumber; //Update the declaration of variable before using it
        int secondNumber;  //Update the declaration of variable before using it
        int thirdNumber;  //Update the declaration of variable before using it
        int fourthNumber;  //Update the declaration of variable before using it
        int fifthNumber;  //Update the declaration of variable before using it

        firstNumber = randomGenerator.nextInt(MAXIMUM - MINIMUM + 1) + MINIMUM;
        secondNumber = randomGenerator.nextInt(MAXIMUM - MINIMUM + 1) + MINIMUM;
        thirdNumber = randomGenerator.nextInt(MAXIMUM - MINIMUM + 1) + MINIMUM;
        fourthNumber = randomGenerator.nextInt(MAXIMUM - MINIMUM + 1) + MINIMUM;
        fifthNumber = randomGenerator.nextInt(MAXIMUM - MINIMUM + 1) + MINIMUM;
        System.out.printf("Random numbers: %d, %d, %d, %d, %d\n",firstNumber,secondNumber,thirdNumber,fourthNumber,fifthNumber);

        // Declare the largest value
        int maximumValue;
        maximumValue = Math.max(firstNumber, secondNumber);
        maximumValue = Math.max(maximumValue, thirdNumber);
        maximumValue = Math.max(maximumValue, fourthNumber);
        maximumValue = Math.max(maximumValue, fifthNumber);
        System.out.printf("The largest value is %d.\n",maximumValue);
     }
 }