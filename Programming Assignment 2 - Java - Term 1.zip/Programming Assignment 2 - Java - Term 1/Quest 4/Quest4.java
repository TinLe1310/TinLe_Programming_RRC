/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created: 2022-01-21
 * Updated: 2022-01-21
 */

 // Quest 3.18.7.66
 import java.util.Scanner;
 public class Quest4
 {
     public static void main(String[] args)
     {
         // Enter a phone number as a String of 10 digits
         Scanner keyboard = new Scanner(System.in);
         String phoneNumber ="";  //Update the declaration of variable before using it

         System.out.printf("Please enter 10 digits: ");
         phoneNumber = keyboard.nextLine();

         System.out.printf("\n");

         // Format the phone number
         String firstPart = ""; //Update the declaration of variable before using it
         String secondPart = ""; //Update the declaration of variable before using it
         String thirdPart = ""; //Update the declaration of variable before using it

         firstPart = phoneNumber.substring(0,3);
         secondPart = phoneNumber.substring(3,6);
         thirdPart = phoneNumber.substring(6);
         System.out.printf("The supplied number formatted as a telephone number is (%s) %s-%s.\n",firstPart,secondPart,thirdPart);
     }
 }