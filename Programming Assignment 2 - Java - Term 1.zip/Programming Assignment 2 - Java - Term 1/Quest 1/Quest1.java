/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created: 2022-01-21
 * Updated: 2022-01-21
 */

// Quest 3.18.6.54
import java.util.Scanner;

public class Quest1
{
     public static void main(String[] args)
     {
         // Enter a number as input from keyboard
         Scanner keyboard = new Scanner(System.in);
         double valueToBeCubed; //Update the declaration of variable before using it

         System.out.printf("Please enter a value to be cubed: ");
         valueToBeCubed = keyboard.nextInt();

         System.out.printf("\n");

         // Calculate and output the cubed value
         double calculatedCubedValue = Math.pow(valueToBeCubed,3);
         System.out.printf("The cubed value of %.1f is %.1f.\n",valueToBeCubed,calculatedCubedValue);
     }
}