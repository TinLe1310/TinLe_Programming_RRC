/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created: 2022-01-21
 * Updated: 2022-01-21
 */

 // Quest 3.18.7.58
 import java.util.Scanner;
 import java.text.DecimalFormat;

 public class Quest2
 {
     public static void main(String[] args)
     {
         // Enter a number as radius input.
         Scanner keyboard = new Scanner(System.in);
         double radius;  //Update the declaration of variable before using it
         double circumference; //Update the declaration of variable before using it
         double area; //Update the declaration of variable before using it

         System.out.printf("Please enter a value for the radius of a circle in centimeters: ");
         radius = keyboard.nextDouble();

         System.out.printf("\n");

         // Calculate and output the circumference
         circumference = radius * 2 * Math.PI;
         DecimalFormat formatted = new DecimalFormat("#,##0.00");
         System.out.printf("The circumference of a circle with a radius of %.2f is %s cm.\n\n",radius,formatted.format(circumference));

         // Calculate and output the area
         area = Math.pow(radius,2) * Math.PI;
         System.out.printf("The area of a circle with a radius of %.2f is %.2f cm\u00b2.\n",radius,area);
     }
 }
