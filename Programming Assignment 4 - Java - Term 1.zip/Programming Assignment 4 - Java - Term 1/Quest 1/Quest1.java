/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created:   2022-01-31
 * Updated:   2022-01-31
 */

 // Quest 6.14.6.51
import java.util.Scanner;
public class Quest1
{
    public static void main(String[] args)
    {
        Scanner keyboard = new Scanner(System.in);
        int inputNumber;
        int i;
        int factorial = 1;

        System.out.printf("Please enter an integer value: ");
        inputNumber = keyboard.nextInt();

        for (i = 1; i <= inputNumber; i++)
        {
            factorial *= i;
        }
        System.out.printf("The factorial of %d is %d.\n",inputNumber,factorial);
    }
}
