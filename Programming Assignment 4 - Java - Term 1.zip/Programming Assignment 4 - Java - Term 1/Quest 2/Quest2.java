/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created:   2022-01-31
 * Updated:   2022-01-31
 */

// Quest 6.14.7.60
import java.util.Scanner;
public class Quest2
{
    public static void main(String[] args)
    {
        Scanner keyboard = new Scanner(System.in);
        String websiteText = "";
        String address = "";
        int i = 0;
        int position;


        System.out.printf("** Enter \"stop\" to end the program **\n");
        do
        {
            System.out.printf("Please enter a website URL (e.g. www.rrc.ca) :");
            websiteText = keyboard.nextLine();
            position = websiteText.lastIndexOf(".");

            if (position != -1)
            {
              address = websiteText.substring(position);
              i += address.equals(".com") ? 1 : 0;
            }
        } while ( !websiteText.equalsIgnoreCase("stop"));
        System.out.printf("There %s %d commercial website%s entered.\n",i>1 ? "were" : "was", i, i>1 ? "s" : "");
    }
}