/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created:   2022-01-31
 * Updated:   2022-01-31
 */

 // Quest 6.14.7.62
import java.util.Scanner;
public class Quest3
{
    public static void main(String[] args)
    {
        Scanner keyboard = new Scanner(System.in);
        String usersEmail = "";
        int i;
        int checkValue = 0;

        System.out.printf("Please enter your email address: ");
        usersEmail = keyboard.nextLine();

        for (i = 0; i < usersEmail.length(); i++)
        {
            checkValue += usersEmail.charAt(i) == '@' ? 1 : 0;
        }
        System.out.printf("The email address entered is %s.\n", checkValue != 1 ? "invalid" : "valid");
    }
}