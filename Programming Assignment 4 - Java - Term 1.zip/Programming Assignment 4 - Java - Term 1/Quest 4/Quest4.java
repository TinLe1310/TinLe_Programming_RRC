/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created:   2022-01-31
 * Updated:   2022-01-31
 */

 // Quest Method
import java.util.Scanner;
public class Quest4
{
    public static void main(String[] args)
    {
        int numberOfVisit;
        String mealCodePlan = "";
        double totalCostValue;

        numberOfVisit = visitDays();
        if (numberOfVisit > 0)
        {
            mealCodePlan = mealCode();
            totalCostValue = totalCost(numberOfVisit, mealCodePlan);
            System.out.printf("The total cost of the visit is %.2f.\n",totalCostValue);
        }
    }

    // Promt and accept for the number of visit days.
    public static int visitDays()
    {
        Scanner keyboard = new Scanner(System.in);
        int inputNumber;

        do
        {
            System.out.printf("Enter the number of days of the visit: ");
            inputNumber = Integer.parseInt(keyboard.nextLine());
        } while (inputNumber < 0);
        return inputNumber;
    }

    // Promt and accept for the meal code plan.
    public static String mealCode()
    {
        Scanner keyboard = new Scanner(System.in);
        String inputMealCode;
        char response ='0';

        do
        {
             System.out.printf("Enter the meal code plan (A, B, N): ");
             inputMealCode = keyboard.nextLine();

             if (inputMealCode.length() == 1)
             {
                inputMealCode = inputMealCode.toUpperCase();
                response = inputMealCode.charAt(0);
             }
        } while (response != 'A' && response != 'B' && response != 'N' );
        return inputMealCode;
    }

    // Calculate the total cost of the trip.
    public static double totalCost(int numberOfVisit, String mealCodePlan)
    {
        double costPerVisit;
        final double MEAL_PLAN_A = 169;
        final double MEAL_PLAN_B = 112;
        final double MEAL_PLAN_C = 99.99;

        switch (mealCodePlan)
        {
             case "A":
                costPerVisit = MEAL_PLAN_A;
                break;
             case "B":
                costPerVisit = MEAL_PLAN_B;
                break;
             default :
                costPerVisit = MEAL_PLAN_C;
        }
        return numberOfVisit * costPerVisit;
    }
}