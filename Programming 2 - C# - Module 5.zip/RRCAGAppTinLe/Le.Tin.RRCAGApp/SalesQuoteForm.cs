﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Globalization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Le.Tin.Business;
using static System.Net.Mime.MediaTypeNames;

namespace Le.Tin.RRCAGApp
{
    public partial class SalesQuoteForm : Form
    {
        private decimal vehicleSalePriceInput = 0m;
        private decimal tradeInValueInput = 0m;

        public SalesQuoteForm()
        {
            InitializeComponent();

            this.Load += SalesQuoteForm_Load;
            this.btnCalculateQuote.Click += BtnCalculateQuote_Click;
            this.txtVehicleSalePrice.TextChanged += TxtVehicleSalePrice_TextChanged;
            this.txtTradeInValue.TextChanged += TxtVehicleSalePrice_TextChanged;
            this.chkStereoSystem.CheckedChanged += Checkboxes_CheckedChanged;
            this.chkLeatherInterior.CheckedChanged += Checkboxes_CheckedChanged;
            this.chkComputerNavigation.CheckedChanged += Checkboxes_CheckedChanged;
            this.radStandard.CheckedChanged += RadioButtons_CheckedChanged;
            this.radPearlized.CheckedChanged += RadioButtons_CheckedChanged;
            this.radCustomizedDetailing.CheckedChanged += RadioButtons_CheckedChanged;
            this.nupdNoOfYears.ValueChanged += NumericUpDown_ValueChanged;
            this.nupdAnnualInterestRate.ValueChanged += NumericUpDown_ValueChanged;
            this.btnReset.Click += BtnReset_Click;
            this.errorProvider1.SetIconPadding(this.txtVehicleSalePrice,3);
            this.errorProvider1.SetIconPadding(this.txtTradeInValue,3); 
        }

        /// <summary>
        /// Handles Click event of Reset button
        /// </summary>
        private void BtnReset_Click(object sender, EventArgs e)
        {
            MessageBoxButtons messageBox = MessageBoxButtons.YesNo;
            
            DialogResult dialogResult = MessageBox.Show("Do you want to reset the form?","Reset Form",
                                                        messageBox,MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            if (dialogResult == DialogResult.Yes)
            {
                InitialForm();
            }
        }

        /// <summary>
        /// Handles Changed event of NumericUpDown 
        /// </summary>
        private void NumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            if (this.lblMonthlyPayment.Text != string.Empty)
            {
                SummaryCalculated();
            }
        }

        /// <summary>
        /// Handles Load event for SalesQuote form.
        /// </summary>
        private void SalesQuoteForm_Load(object sender, EventArgs e)
        {
            InitialForm();
        }

        /// <summary>
        /// Handles Changed event of Checkboxes
        /// </summary>
        private void Checkboxes_CheckedChanged(object sender, EventArgs e)
        {
            CheckingAsscessoriesChosen();

            if (this.lblOptions.Text != string.Empty)
            {
                SummaryCalculated();
            }
        }

        /// <summary>
        /// Handles Changed event of Radiobuttons
        /// </summary>
        private void RadioButtons_CheckedChanged(object sender, EventArgs e)
        {
            CheckingExteriorFinishChosen();

            if (this.lblOptions.Text != string.Empty)
            {
                SummaryCalculated();
            }
        }

        /// <summary>
        /// Handles TextChanged event of textbox VehicleSalePrice
        /// </summary>
        private void TxtVehicleSalePrice_TextChanged(object sender, EventArgs e)
        {
            this.lblVehicleSalePrice.Text = string.Empty;
            this.lblOptions.Text = string.Empty;
            this.lblSubtotal.Text = string.Empty;
            this.lblSalesTax.Text = string.Empty;
            this.lblTotal.Text = string.Empty;
            this.lblTradeIn.Text = string.Empty;
            this.lblAmountDue.Text = string.Empty;
            this.lblMonthlyPayment.Text = string.Empty;
        }

        /// <summary>
        /// Handles Click event of button CalculateQuote
        /// </summary>
        private void BtnCalculateQuote_Click(object sender, EventArgs e)
        {
            bool isVehicleSalePriceValid = false;
            bool isTradeInValueValid = false;

            this.errorProvider1.SetError(txtVehicleSalePrice, string.Empty);
            this.errorProvider1.SetError(txtTradeInValue, string.Empty);
            /// <summary>
            /// ErrorProvider Handling for txtVehicleSalePrice
            /// </summary>
            if (!IsValueBlank(this.txtVehicleSalePrice.Text))
            {
                this.errorProvider1.SetError(this.txtVehicleSalePrice, "Vehicle price is a required field.");
            }
            else if (this.txtVehicleSalePrice.Text.Any(char.IsLetter) || CheckingSymbols(this.txtVehicleSalePrice.Text))
            {
                    this.errorProvider1.SetError(this.txtVehicleSalePrice, "Vehicle price cannot contain letters or special characters.");
            }
            else 
            {
                this.vehicleSalePriceInput = Decimal.Parse(this.txtVehicleSalePrice.Text, NumberStyles.AllowLeadingSign);

                if (vehicleSalePriceInput <= 0)
                {
                    this.errorProvider1.SetError(this.txtVehicleSalePrice, "Vehicle price cannot be less than or equal to 0.");
                }
                else
                {
                    isVehicleSalePriceValid = true;
                }      
            }

            /// <summary>
            /// ErrorProvider Handling for txtTradeInValue
            /// </summary>
            if (!IsValueBlank(this.txtTradeInValue.Text))
            {
                this.errorProvider1.SetError(this.txtTradeInValue, "Trade-in value is a required field.");
            }
            else if (this.txtTradeInValue.Text.Any(char.IsLetter) || CheckingSymbols(this.txtTradeInValue.Text))
            {
                this.errorProvider1.SetError(this.txtTradeInValue, "Trade-in value cannot contain letters or special characters.");
            }
            else
            {
                this.tradeInValueInput = Decimal.Parse(this.txtTradeInValue.Text, NumberStyles.AllowLeadingSign);

                if (tradeInValueInput < 0)
                {
                    this.errorProvider1.SetError(this.txtTradeInValue, "Trade-in value cannot be less than 0.");
                }
                else if (tradeInValueInput > vehicleSalePriceInput)
                {
                    this.errorProvider1.SetError(this.txtTradeInValue, "Trade-in value cannot exceed the vehicle sale price.");
                }
                else
                {
                    isTradeInValueValid = true;
                }      
            }

            if (isVehicleSalePriceValid && isTradeInValueValid)
            {
                SummaryCalculated();
            }
        }

        /// <summary>
        /// Method creating initial  state of the form
        /// </summary>
        private void InitialForm()
        {
            this.errorProvider1.SetError(txtVehicleSalePrice, string.Empty);
            this.errorProvider1.SetError(txtTradeInValue, string.Empty);
            this.txtVehicleSalePrice.Focus();
            this.txtVehicleSalePrice.Text = string.Empty;
            this.txtTradeInValue.Text = "0";
            this.lblVehicleSalePrice.Text = string.Empty;
            this.lblOptions.Text = string.Empty;
            this.lblSubtotal.Text = string.Empty;
            this.lblSalesTax.Text = string.Empty;
            this.lblTotal.Text = string.Empty;
            this.lblTradeIn.Text = string.Empty;
            this.lblAmountDue.Text = string.Empty;
            this.chkStereoSystem.Checked = false;
            this.chkLeatherInterior.Checked = false;
            this.chkComputerNavigation.Checked = false;
            this.radStandard.Checked = true;
            this.radPearlized.Checked = false;
            this.radCustomizedDetailing.Checked = false;
            this.nupdNoOfYears.Value = 1;
            this.nupdAnnualInterestRate.Value = 5;
            this.lblMonthlyPayment.Text = string.Empty;
        }

        /// <summary>
        /// Method calculating form's summary part
        /// </summary>
        private void SummaryCalculated()
        {
            if (this.vehicleSalePriceInput > 0 && this.tradeInValueInput >=0)
            {
                SalesQuote salesquote = new SalesQuote(this.vehicleSalePriceInput, this.tradeInValueInput, 0.12m, CheckingAsscessoriesChosen(), CheckingExteriorFinishChosen());

                // Display vehicle sale price input as currency
                this.lblVehicleSalePrice.Text = string.Format("{0:c}", vehicleSalePriceInput);
                //Display options output
                this.lblOptions.Text = string.Format("{0:n}", salesquote.TotalOptions);
                //Display subtotal output
                this.lblSubtotal.Text = string.Format("{0:c}", salesquote.SubTotal);
                //Display sale tax amount output
                this.lblSalesTax.Text = string.Format("{0:n}", salesquote.SalesTax);
                //Display total output
                this.lblTotal.Text = string.Format("{0:c}", salesquote.Total);
                // Display trade in value input
                this.lblTradeIn.Text = string.Format("-{0:n}", tradeInValueInput);
                //Display amount due output
                this.lblAmountDue.Text = string.Format("{0:c}", salesquote.AmountDue);
                //Display monthly payment output
                int numberOfPeriod = (int)(this.nupdNoOfYears.Value) * 12;
                decimal rate = this.nupdAnnualInterestRate.Value / 100 / 12;
                decimal presentValue = salesquote.AmountDue;
                this.lblMonthlyPayment.Text = string.Format("{0:c}", Financial.GetPayment(rate, numberOfPeriod, presentValue));
            }   
        }

        /// <summary>
        /// Method checking blank textbox
        /// </summary>
        private bool IsValueBlank(string text)
        {
            return (text.Trim().Length > 0);
        }

        /// <summary>
        /// Method checking symbols inside textbox
        /// </summary>
        private bool CheckingSymbols(string text)
        {
            int counter = 0;
            bool result = true;

            for (int i = 0; i < text.Length; i++)
            {
                if (text[i] == '-')
                {
                    if (i != 0)
                    {
                        counter++;
                    }
                }
            }

            if (counter == 0)
            {
                string newText = text.Substring(1);
                if (newText.All(char.IsNumber))
                {
                    result = false;
                }
            }

            return result;
        }

        /// <summary>
        /// Method checking accessories chosen
        /// </summary>
        private Accessories CheckingAsscessoriesChosen()
        {
            Accessories accessoriesChosen = Accessories.None;

            CheckBox[] checkBoxes = { chkStereoSystem, chkLeatherInterior, chkComputerNavigation };

            if (checkBoxes[0].Checked && checkBoxes[1].Checked && checkBoxes[2].Checked)
                accessoriesChosen = Accessories.All;
            else if (checkBoxes[0].Checked && checkBoxes[1].Checked)
                accessoriesChosen = Accessories.StereoAndLeather;
            else if (checkBoxes[0].Checked && checkBoxes[2].Checked)
                accessoriesChosen = Accessories.StereoAndNavigation;
            else if (checkBoxes[1].Checked && checkBoxes[2].Checked)
                accessoriesChosen = Accessories.LeatherAndNavigation;
            else if (checkBoxes[0].Checked)
                accessoriesChosen = Accessories.StereoSystem;
            else if (checkBoxes[1].Checked)
                accessoriesChosen = Accessories.LeatherInterior;
            else if (checkBoxes[2].Checked)
                accessoriesChosen = Accessories.ComputerNavigation;
            else
                accessoriesChosen = Accessories.None;

            return accessoriesChosen;
        }

        /// <summary>
        /// Method checking exterior finish chosen
        /// </summary>
        private ExteriorFinish CheckingExteriorFinishChosen()
        {
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;

            RadioButton[] radioButtons = { radStandard, radPearlized, radCustomizedDetailing };
            ExteriorFinish[] exteriors = { ExteriorFinish.Standard, ExteriorFinish.Pearlized, ExteriorFinish.Custom };

            for (int i = 0; i < radioButtons.Length; i++)
            {
                if (radioButtons[i].Checked)
                {
                    exteriorFinishChosen = exteriors[i];
                }
            }
            return exteriorFinishChosen;
        }
    }
}
