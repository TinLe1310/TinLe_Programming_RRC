﻿/*
 * Name: Tin Le
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-09-13
 * Updated: 2022-09-14
 */

using System;

namespace Le.Tin.Business
{
    ///<summary>
    /// This class contains functionality that supports the business process of determining a quote for the sale of a vehicle.
    ///</summary>
    public class SalesQuote
    {
        private decimal vehicleSalePrice;
        private decimal tradeInAmount;
        private decimal salesTaxRate;
        private Accessories accessoriesChosen;
        private ExteriorFinish exteriorFinishChosen;

        /// <summary>
        /// Gets and sets the vehicle sale price.
        /// </summary>
        /// <exception cref="System.ArgumentOutOfRangeException">
        /// Thrown when the vehicle sale price is less than or equal to 0. 
        /// </exception>
        public decimal VehicleSalePrice
        {
            get
            {
                return this.vehicleSalePrice;
            }
            set
            {
                if (value <= 0)
                {
                    ArgumentOutOfRangeException exception;
                    exception = new ArgumentOutOfRangeException("value", "The value cannot be less than or equal to 0.");                   
                    throw exception;
                }

                this.vehicleSalePrice = value;
            }
        }

        /// <summary>
        /// Gets and sets the trade in amount.
        /// </summary>
        /// <exception cref="System.ArgumentOutOfRangeException">
        /// Thrown when the trade in amount is less than 0.
        /// </exception>
        public decimal TradeInAmount
        {
            get
            {
                return this.tradeInAmount;
            }
            set
            {                
                if (value < 0)
                {
                    ArgumentOutOfRangeException exception;
                    exception = new ArgumentOutOfRangeException("value", "The value cannot be less than 0.");
                    throw exception;
                }

                this.tradeInAmount = value;
            }
        }

        /// <summary>
        /// Gets and sets the accessories that were chosen.
        /// </summary>     
        /// <exception cref="System.ComponentModel.InvalidEnumArgumentException">
        /// Thrown when the accessories chosen is an invalid argument. 
        /// </exception>
        public Accessories AccessoriesChosen
        {
            get
            {
                return this.accessoriesChosen;
            }
            set
            {                
                if (!Enum.IsDefined(typeof(Accessories),value))
                {
                    System.ComponentModel.InvalidEnumArgumentException exception;
                    exception = new System.ComponentModel.InvalidEnumArgumentException("The value is an invalid enumeration value.");
                    throw exception;
                }

                this.accessoriesChosen = value;
            }
        }

        /// <summary>
        /// Gets and sets the exterior finish that was chosen.
        /// </summary>
        /// <exception cref="System.ComponentModel.InvalidEnumArgumentException">
        /// Thrown when the exterior finish chosen is an invalid argument.
        /// </exception>
        public ExteriorFinish ExteriorFinishChosen
        {
            get
            {
                return this.exteriorFinishChosen;
            }
            set
            {               
                if (!Enum.IsDefined(typeof(ExteriorFinish), value))
                {
                    System.ComponentModel.InvalidEnumArgumentException exception;
                    exception = new System.ComponentModel.InvalidEnumArgumentException("The value is an invalid enumeration value.");
                    throw exception;
                }

                this.exteriorFinishChosen = value;
            }
        }

        /// <summary>
        /// Gets the cost of accessories chosen.
        /// </summary>         
        public decimal AccessoriesCost
        {
            get
            {
                decimal stereoSystem = 505.05M;
                decimal leatherInterior = 1010.10M;
                decimal computerNavigation = 1515.15M;
                decimal accessoriesCost = 0M;
                
                switch (AccessoriesChosen)
                {
                    case Accessories.StereoSystem:
                        accessoriesCost = stereoSystem;
                        break;
                    case Accessories.LeatherInterior:
                        accessoriesCost = leatherInterior;
                        break;
                    case Accessories.StereoAndLeather:
                        accessoriesCost = stereoSystem + leatherInterior;
                        break;
                    case Accessories.ComputerNavigation:
                        accessoriesCost = computerNavigation;
                        break;
                    case Accessories.StereoAndNavigation:
                        accessoriesCost = stereoSystem + computerNavigation;
                        break;
                    case Accessories.LeatherAndNavigation:
                        accessoriesCost = leatherInterior + computerNavigation;
                        break;
                    case Accessories.All:
                        accessoriesCost = stereoSystem + leatherInterior + computerNavigation;
                        break;
                    default:
                        break;
                }

                return accessoriesCost;
            }  
        }

        /// <summary>
        /// Gets the cost of the exterior finish chosen.
        /// </summary>      
        public decimal FinishCost
        {
            get
            {
                decimal standard = 202.02M;
                decimal pearlized = 404.04M;
                decimal custom = 606.06M;
                decimal exteriorFinishCost = 0M;

                switch (ExteriorFinishChosen)
                {
                    case ExteriorFinish.Standard:
                        exteriorFinishCost = standard;
                        break;
                    case ExteriorFinish.Pearlized:
                        exteriorFinishCost = pearlized;
                        break;
                    case ExteriorFinish.Custom:
                        exteriorFinishCost = custom;
                        break;
                    default:
                        break;
                }

                return exteriorFinishCost;
            }
        }

        /// <summary>
        /// Gets the sum of the cost of accessories chosen and the cost of the exterior finish chosen
        /// (rounded to two decimal places).
        /// </summary>       
        public decimal TotalOptions
        {
            get
            {
                return decimal.Round(AccessoriesCost + FinishCost, 2);
            }
        }

        /// <summary>
        /// Gets the sum of the vehicle’s sale price, accessories and exterior finish costs
        /// (rounded to two decimal places).
        /// </summary>       
        public decimal SubTotal
        {
            get
            {
                return decimal.Round(VehicleSalePrice + TotalOptions, 2);
            }
        }

        /// <summary>
        /// Gets the amount of tax to charge based on the subtotal
        /// (rounded to two decimal places).
        /// </summary>       
        public decimal SalesTax
        {
            get
            {
                return decimal.Round(this.salesTaxRate * SubTotal, 2);
            }
        }

        /// <summary>
        /// Gets the sum of the subtotal and taxes.
        /// </summary>       
        public decimal Total
        {
            get
            {
                return SalesTax + SubTotal;
            }                         
        }

        /// <summary>
        /// Gets the result of subtracting the trade-in amount from the total
        /// (rounded to two decimal places).
        /// </summary>
        public decimal AmountDue
        {
            get
            {
                return decimal.Round(Total - TradeInAmount, 2);
            }
        }

        /// <summary>
        /// Initializes an instance of SalesQuote with a vehicle price, trade-in value,
        /// sales tax rate, accessories chosen and exterior finish chosen.
        /// </summary>
        /// <param name="vehicleSalePrice">The selling price of the vehicle being sold.</param>
        /// <param name="tradeInAmount">The amount offered to the customer for the trade in of their vehicle.</param>
        /// <param name="salesTaxRate">The tax rate applied to the sale of a vehicle.</param>
        /// <param name="accessoriesChosen">The value of the chosen accessories.</param>
        /// <param name="exteriorFinishChosen">The value of the chosen exterior finish.</param>
        /// <exception cref="System.ArgumentOutOfRangeException">
        /// Thrown when the vehicle sale price is less than or equal to 0. 
        /// </exception>
        /// <exception cref="System.ArgumentOutOfRangeException">
        /// Thrown when the trade in amount is less than 0.
        /// </exception>
        /// <exception cref="System.ArgumentOutOfRangeException">
        /// Thrown when the sales tax rate is less than 0 or greater than 1.
        /// </exception>
        /// <exception cref="System.ComponentModel.InvalidEnumArgumentException">
        /// Thrown when the accessories chosen or exterior finish chosen is an invalid argument. 
        /// </exception>
        public SalesQuote(decimal vehicleSalePrice, decimal tradeInAmount, decimal salesTaxRate, Accessories accessoriesChosen, ExteriorFinish exteriorFinishChosen)
        {     
            if (vehicleSalePrice <= 0)
            {
                ArgumentOutOfRangeException exception;
                exception = new ArgumentOutOfRangeException("vehicleSalePrice", "The argument cannot be less than or equal to 0.");
                throw exception;
            }

            if (tradeInAmount < 0)
            {
                ArgumentOutOfRangeException exception;
                exception = new ArgumentOutOfRangeException("tradeInAmount", "The argument cannot be less than 0.");
                throw exception;
            }

            if (salesTaxRate < 0 || salesTaxRate > 1)
            {
                ArgumentOutOfRangeException exception;
                exception = new ArgumentOutOfRangeException("salesTaxRate", salesTaxRate < 0 ? "The argument cannot be less than 0." : "The argument cannot be greater than 1.");
                throw exception;
            }

            if (!Enum.IsDefined(typeof(Accessories), accessoriesChosen) || !Enum.IsDefined(typeof(ExteriorFinish), exteriorFinishChosen))
            {
                System.ComponentModel.InvalidEnumArgumentException exception;
                exception = new System.ComponentModel.InvalidEnumArgumentException("The value is an invalid enumeration value.");
                throw exception;
            }

            this.VehicleSalePrice = vehicleSalePrice;
            this.TradeInAmount = tradeInAmount;
            this.salesTaxRate = salesTaxRate;
            this.AccessoriesChosen = accessoriesChosen;
            this.ExteriorFinishChosen = exteriorFinishChosen;
        }

        /// <summary>
        /// Initializes an instance of SalesQuote with a vehicle price, trade-in value,
        /// sales tax rate, no accessories chosen and no exterior finish chosen.
        /// </summary>
        /// <param name="vehicleSalePrice">The selling price of the vehicle being sold.</param>
        /// <param name="tradeInAmount">The amount offered to the customer for the trade in of their vehicle.</param>
        /// <param name="salesTaxRate">The tax rate applied to the sale of a vehicle.</param>
        /// <exception cref="System.ArgumentOutOfRangeException">
        /// Thrown when the vehicle sale price is less than or equal to 0. 
        /// </exception>
        /// <exception cref="System.ArgumentOutOfRangeException">
        /// Thrown when the trade in amount is less than 0.
        /// </exception>
        /// <exception cref="System.ArgumentOutOfRangeException">
        /// Thrown when the sales tax rate is less than 0 or greater than 1.
        /// </exception>
        public SalesQuote(decimal vehicleSalePrice, decimal tradeInAmount, decimal salesTaxRate)
            : this(vehicleSalePrice, tradeInAmount, salesTaxRate, Accessories.None, ExteriorFinish.None)
        {
            // This constructor invokes the other constructor.
        }
    }
}