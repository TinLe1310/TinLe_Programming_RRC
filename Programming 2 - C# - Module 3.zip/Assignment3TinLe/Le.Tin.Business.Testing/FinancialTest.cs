﻿/*
 * Name: Tin Le
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-09-19
 * Updated: 2022-09-20
 */

using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Le.Tin.Business.Testing
{
    [TestClass]
    public class FinancialTest
    {
        /*
         * Method GetPayment(decimal, int, decimal) : decimal
         * 8 testing cases (6 exceptions, 2 execution)
         */
        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetPaymentMethod_NegativeRate_Exception()
        {
            //Arrange
            decimal rate = -0.5m;
            int numberOfPaymentPeriods = 5;
            decimal presentValue = 400m;

            //Act
            decimal actual = Financial.GetPayment(rate, numberOfPaymentPeriods, presentValue);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetPaymentMethod_RateGreaterThanOne_Exception()
        {
            //Arrange
            decimal rate = 1.5m;
            int numberOfPaymentPeriods = 5;
            decimal presentValue = 400m;

            //Act
            decimal actual = Financial.GetPayment(rate, numberOfPaymentPeriods, presentValue);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetPaymentMethod_NegativeNumberOfPaymentPeriods_Exception()
        {
            //Arrange
            decimal rate = 0.5m;
            int numberOfPaymentPeriods = -5;
            decimal presentValue = 400m;

            //Act
            decimal actual = Financial.GetPayment(rate, numberOfPaymentPeriods, presentValue);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetPaymentMethod_NumberOfPaymentPeriodsZero_Exception()
        {
            //Arrange
            decimal rate = 0.5m;
            int numberOfPaymentPeriods = 0;
            decimal presentValue = 400m;

            //Act
            decimal actual = Financial.GetPayment(rate, numberOfPaymentPeriods, presentValue);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetPaymentMethod_NegativePresentValue_Exception()
        {
            //Arrange
            decimal rate = 0.5m;
            int numberOfPaymentPeriods = 5;
            decimal presentValue = -400m;

            //Act
            decimal actual = Financial.GetPayment(rate, numberOfPaymentPeriods, presentValue);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetPaymentMethod_PresentValueZero_Exception()
        {
            //Arrange
            decimal rate = 0.5m;
            int numberOfPaymentPeriods = 5;
            decimal presentValue = 0m;

            //Act
            decimal actual = Financial.GetPayment(rate, numberOfPaymentPeriods, presentValue);
        }

        [TestMethod]
        public void GetPaymentMethod_ReturnPaymentAmount_ZeroRate()
        {
            //Arrange
            decimal rate = 0m;
            int numberOfPaymentPeriods = 5;
            decimal presentValue = 400m;

            //Act
            decimal actual = Financial.GetPayment(rate, numberOfPaymentPeriods, presentValue);

            //Assert
            decimal expected = 80m;
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GetPaymentMethod_ReturnPaymentAmount_PositiveRate()
        {
            //Arrange
            decimal rate = 0.5m;
            int numberOfPaymentPeriods = 5;
            decimal presentValue = 400m;

            //Act
            decimal actual = Financial.GetPayment(rate, numberOfPaymentPeriods, presentValue);

            //Assert
            decimal expected = 230.33m;
            Assert.AreEqual(expected, actual);
        }
    }
}
