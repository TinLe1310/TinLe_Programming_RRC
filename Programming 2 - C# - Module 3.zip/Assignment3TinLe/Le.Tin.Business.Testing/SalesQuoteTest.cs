﻿/*
 * Name: Tin Le
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-09-19
 * Updated: 2022-09-20
 */

using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.ComponentModel;
using System;

namespace Le.Tin.Business.Testing
{
    [TestClass]
    public class SaleQuoteTest
    {
        /*
         * Constructor1: SalesQuote(decimal, decimal, decimal, Accessories, ExteriorFinish)
         * 12 testing cases (7 exceptions, 5 state initialize)
         */
        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor1_NegativeVehicleSalePrice_Exception()
        {
            //Arrange
            decimal vehicleSalePrice = -450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            //Act
            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor1_VehicleSalePriceZero_Exception()
        {
            //Arrange
            decimal vehicleSalePrice = 0m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            //Act
            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor1_NegativeTradeInAmount_Exception()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = -400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            //Act
            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor1_NegativeSalesTaxRate_Exception()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = -0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            //Act
            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor1_SalesTaxRateGreaterThanOne_Exception()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 1.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            //Act
            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidEnumArgumentException))]
        public void Constructor1_InvalidAccessories_Exception()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = (Accessories)99;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            //Act
            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidEnumArgumentException))]
        public void Constructor1_InvalidExteriorFinish_Exception()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = (ExteriorFinish)99;

            //Act
            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
        }

        [TestMethod]
        public void Constructor1_VehicleSalePrice_Initialized()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            //Act
            SalesQuote salesquote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesquote);

            //Assert
            decimal expected = 450m;
            decimal actual = (decimal)target.GetField("vehicleSalePrice");

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Constructor1_TradeInAmount_Initialized()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            //Act
            SalesQuote salesquote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesquote);

            //Assert
            decimal expected = 400m;
            decimal actual = (decimal)target.GetField("tradeInAmount");

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Constructor1_SalesTaxRate_Initialized()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            //Act
            SalesQuote salesquote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesquote);

            //Assert
            decimal expected = 0.15m;
            decimal actual = (decimal)target.GetField("salesTaxRate");

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Constructor1_Accessories_Initialized()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            //Act
            SalesQuote salesquote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesquote);

            //Assert
            Accessories expected = Accessories.StereoSystem;
            Accessories actual = (Accessories)target.GetField("accessoriesChosen");

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Constructor1_ExteriorFinish_Initialized()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            //Act
            SalesQuote salesquote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesquote);

            //Assert
            ExteriorFinish expected = ExteriorFinish.Standard;
            ExteriorFinish actual = (ExteriorFinish)target.GetField("exteriorFinishChosen");

            Assert.AreEqual(expected, actual);
        }

        /*
         * Constructor2: SalesQuote(decimal, decimal, decimal)
         * 10 testing cases (5 exceptions, 5 status initialize)
         */
        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor2_NegativeVehicleSalePrice_Exception()
        {
            //Arrange
            decimal vehicleSalePrice = -450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;

            //Act
            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor2_VehicleSalePriceZero_Exception()
        {
            //Arrange
            decimal vehicleSalePrice = 0m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;

            //Act
            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor2_NegativeTradeInAmount_Exception()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = -400m;
            decimal salesTaxRate = 0.15m;

            //Act
            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor2_NegativeSalesTaxRate_Exception()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = -0.15m;

            //Act
            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor2_SalesTaxRateGreaterThanOne_Exception()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 1.15m;

            //Act
            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);
        }

        [TestMethod]
        public void Constructor2_VehicleSalePrice_Initialized()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;

            //Act
            SalesQuote salesquote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);
            PrivateObject target = new PrivateObject(salesquote);

            //Assert
            decimal expected = 450m;
            decimal actual = (decimal)target.GetField("vehicleSalePrice");

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Constructor2_TradeInAmount_Initialized()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;

            //Act
            SalesQuote salesquote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);
            PrivateObject target = new PrivateObject(salesquote);

            //Assert
            decimal expected = 400m;
            decimal actual = (decimal)target.GetField("tradeInAmount");

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Constructor2_SalesTaxRate_Initialized()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;

            //Act
            SalesQuote salesquote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);
            PrivateObject target = new PrivateObject(salesquote);

            //Assert
            decimal expected = 0.15m;
            decimal actual = (decimal)target.GetField("salesTaxRate");

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Constructor2_Accessories_Initialized()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;

            //Act
            SalesQuote salesquote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);
            PrivateObject target = new PrivateObject(salesquote);

            //Assert
            Accessories expected = Accessories.None;
            Accessories actual = (Accessories)target.GetField("accessoriesChosen");

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Constructor2_ExteriorFinish_Initialized()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;

            //Act
            SalesQuote salesquote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);
            PrivateObject target = new PrivateObject(salesquote);

            //Assert
            ExteriorFinish expected = ExteriorFinish.None;
            ExteriorFinish actual = (ExteriorFinish)target.GetField("exteriorFinishChosen");

            Assert.AreEqual(expected, actual);
        }

        /*
         * VehicleSalePrice Property
         * 6 testing cases
         */
        [TestMethod]
        public void VehicleSalePricePropertyGet_ReturnState()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);

            //Act
            decimal actual = target.VehicleSalePrice;

            //Assert
            decimal expected = 450m;
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void VehicleSalePricePropertySet_NegativeVehicleSalePrice_Exception()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);

            //Act
            target.VehicleSalePrice = -450m;
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void VehicleSalePricePropertySet_VehicleSalePriceZero_Exception()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);

            //Act
            target.VehicleSalePrice = 0m;
        }

        [TestMethod]
        public void VehicleSalePricePropertySet_Positive_UpdatesState()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesQuote);

            //Act
            salesQuote.VehicleSalePrice = 500m;

            //Assert
            decimal expected = 500m;
            decimal actual = (decimal)target.GetField("vehicleSalePrice");

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void VehicleSalePricePropertySet_Negative_StateNotUpdated()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);

            //Act
            try
            {
                salesQuote.VehicleSalePrice = -500m;
            }
            catch (ArgumentOutOfRangeException)
            {
                //Assert
                decimal expected = 450m;

                PrivateObject target = new PrivateObject(salesQuote);
                decimal actual = (decimal)target.GetField("vehicleSalePrice");

                Assert.AreEqual(expected, actual);
            }
        }

        [TestMethod]
        public void VehicleSalePricePropertySet_Zero_StateNotUpdated()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);

            //Act
            try
            {
                salesQuote.VehicleSalePrice = 0m;
            }
            catch (ArgumentOutOfRangeException)
            {
                //Assert
                decimal expected = 450m;

                PrivateObject target = new PrivateObject(salesQuote);
                decimal actual = (decimal)target.GetField("vehicleSalePrice");

                Assert.AreEqual(expected, actual);
            }
        }

        /*
         * TradeInAmount Property
         * 4 testing cases
         */
        [TestMethod]
        public void TradeInAmountPropertyGet_ReturnState()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);

            //Act
            decimal actual = target.TradeInAmount;

            //Assert
            decimal expected = 400m;
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void TradeInAmountPropertySet_NegativeTradeInAmount_Exception()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);

            //Act
            target.VehicleSalePrice = -400m;
        }

        [TestMethod]
        public void TradeInAmountPropertySet_ZeroOrPositive_UpdatesState()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesQuote);

            //Act
            salesQuote.TradeInAmount = 300m;

            //Assert
            decimal expected = 300m;
            decimal actual = (decimal)target.GetField("tradeInAmount");

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TradeInAmountPropertySet_Negative_StateNotUpdated()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);

            //Act
            try
            {
                salesQuote.TradeInAmount = -300m;
            }
            catch (ArgumentOutOfRangeException)
            {
                //Assert
                decimal expected = 400m;

                PrivateObject target = new PrivateObject(salesQuote);
                decimal actual = (decimal)target.GetField("tradeInAmount");

                Assert.AreEqual(expected, actual);
            }
        }

        /*
         * AccessoriesChosen Property
         * 4 testing cases
         */
        [TestMethod]
        public void AccessoriesChosenPropertyGet_ReturnState()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);

            //Act
            Accessories actual = target.AccessoriesChosen;

            //Assert
            Accessories expected = Accessories.StereoSystem;
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidEnumArgumentException))]
        public void AccessoriesChosenPropertySet_InvalidEnum_Exception()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);

            //Act
            target.AccessoriesChosen = (Accessories)99;
        }

        [TestMethod]
        public void AccessoriesChosenPropertySet_ValidEnum_UpdatesState()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesQuote);

            //Act
            salesQuote.AccessoriesChosen = Accessories.StereoAndNavigation;

            //Assert
            Accessories expected = Accessories.StereoAndNavigation;
            Accessories actual = (Accessories)target.GetField("accessoriesChosen");

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void AccessoriesChosenPropertySet_InvalidEnum_StateNotUpdated()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);

            //Act
            try
            {
                salesQuote.AccessoriesChosen = (Accessories)99;
            }
            catch (InvalidEnumArgumentException)
            {
                //Assert
                Accessories expected = Accessories.StereoSystem;

                PrivateObject target = new PrivateObject(salesQuote);
                Accessories actual = (Accessories)target.GetField("accessoriesChosen");

                Assert.AreEqual(expected, actual);
            }
        }

        /*
         * ExteriorFinishChosen Property
         * 4 testing cases
         */
        [TestMethod]
        public void ExteriorFinishChosenPropertyGet_ReturnState()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);

            //Act
            ExteriorFinish actual = target.ExteriorFinishChosen;

            //Assert
            ExteriorFinish expected = ExteriorFinish.Standard;
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidEnumArgumentException))]
        public void ExteriorFinishChosenPropertySet_InvalidEnum_Exception()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            SalesQuote target = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);

            //Act
            target.ExteriorFinishChosen = (ExteriorFinish)99;
        }

        [TestMethod]
        public void ExteriorFinishChosenPropertySet_ValidEnum_UpdatesState()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesQuote);

            //Act
            salesQuote.ExteriorFinishChosen = ExteriorFinish.Pearlized;

            //Assert
            ExteriorFinish expected = ExteriorFinish.Pearlized;
            ExteriorFinish actual = (ExteriorFinish)target.GetField("exteriorFinishChosen");

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void ExteriorFinishChosenPropertySet_InvalidEnum_StateNotUpdated()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.StereoSystem;
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);

            //Act
            try
            {
                salesQuote.ExteriorFinishChosen = (ExteriorFinish)99;
            }
            catch (InvalidEnumArgumentException)
            {
                //Assert
                ExteriorFinish expected = ExteriorFinish.Standard;

                PrivateObject target = new PrivateObject(salesQuote);
                ExteriorFinish actual = (ExteriorFinish)target.GetField("exteriorFinishChosen");

                Assert.AreEqual(expected, actual);
            }
        }

        /*
         * AccessoriesCost Property
         * 8 testing cases
         */
        [TestMethod]
        public void AccessoriesCostPropertyGet_StereoSystem_ReturnCostOfAccessoriesChosen()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.None;
            ExteriorFinish exteriorFinish = ExteriorFinish.None;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesQuote);
            
            target.SetField("accessoriesChosen", Accessories.StereoSystem);

            //Act
            decimal actual = salesQuote.AccessoriesCost;

            //Assert
            decimal expected = 505.05m;

            Assert.AreEqual(expected, actual); 
        }

        [TestMethod]
        public void AccessoriesCostPropertyGet_LeatherInterior_ReturnCostOfAccessoriesChosen()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.None;
            ExteriorFinish exteriorFinish = ExteriorFinish.None;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesQuote);
         
            target.SetField("accessoriesChosen", Accessories.LeatherInterior);

            //Act
            decimal actual = salesQuote.AccessoriesCost;

            //Assert
            decimal expected = 1010.10m;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void AccessoriesCostPropertyGet_StereoAndLeather_ReturnCostOfAccessoriesChosen()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.None;
            ExteriorFinish exteriorFinish = ExteriorFinish.None;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesQuote);

            target.SetField("accessoriesChosen", Accessories.StereoAndLeather);

            //Act
            decimal actual = salesQuote.AccessoriesCost;

            //Assert
            decimal expected = 505.05m + 1010.10m;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void AccessoriesCostPropertyGet_ComputerNavigation_ReturnCostOfAccessoriesChosen()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.None;
            ExteriorFinish exteriorFinish = ExteriorFinish.None;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesQuote);

            target.SetField("accessoriesChosen", Accessories.ComputerNavigation);

            //Act
            decimal actual = salesQuote.AccessoriesCost;

            //Assert
            decimal expected = 1515.15m;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void AccessoriesCostPropertyGet_StereoAndNavigation_ReturnCostOfAccessoriesChosen()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.None;
            ExteriorFinish exteriorFinish = ExteriorFinish.None;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesQuote);

            target.SetField("accessoriesChosen", Accessories.StereoAndNavigation);

            //Act
            decimal actual = salesQuote.AccessoriesCost;

            //Assert
            decimal expected = 505.05m + 1515.15m;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void AccessoriesCostPropertyGet_LeatherAndNavigation_ReturnCostOfAccessoriesChosen()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.None;
            ExteriorFinish exteriorFinish = ExteriorFinish.None;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesQuote);

            target.SetField("accessoriesChosen", Accessories.LeatherAndNavigation);

            //Act
            decimal actual = salesQuote.AccessoriesCost;

            //Assert
            decimal expected = 1010.10m + 1515.15m;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void AccessoriesCostPropertyGet_All_ReturnCostOfAccessoriesChosen()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.None;
            ExteriorFinish exteriorFinish = ExteriorFinish.None;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesQuote);

            target.SetField("accessoriesChosen", Accessories.All);

            //Act
            decimal actual = salesQuote.AccessoriesCost;

            //Assert
            decimal expected = 505.05m + 1010.10m + 1515.15m;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void AccessoriesCostPropertyGet_None_ReturnCostOfAccessoriesChosen()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.None;
            ExteriorFinish exteriorFinish = ExteriorFinish.None;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesQuote);

            target.SetField("accessoriesChosen", Accessories.None);

            //Act
            decimal actual = salesQuote.AccessoriesCost;

            //Assert
            decimal expected = 0m;

            Assert.AreEqual(expected, actual);
        }

        /*
         * FinishCost Property
         * 4 testing cases
         */
        [TestMethod]
        public void FinishCostPropertyGet_Standard_ReturnCostOfExteriorFinishChosen()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.None;
            ExteriorFinish exteriorFinish = ExteriorFinish.None;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesQuote);

            target.SetField("exteriorFinishChosen", ExteriorFinish.Standard);
            
            //Act
            decimal actual = salesQuote.FinishCost;

            //Assert
            decimal expected = 202.02m;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void FinishCostPropertyGet_Pearlized_ReturnCostOfExteriorFinishChosen()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.None;
            ExteriorFinish exteriorFinish = ExteriorFinish.None;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesQuote);

            target.SetField("exteriorFinishChosen", ExteriorFinish.Pearlized);

            //Act
            decimal actual = salesQuote.FinishCost;

            //Assert
            decimal expected = 404.04m;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void FinishCostPropertyGet_Custom_ReturnCostOfExteriorFinishChosen()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.None;
            ExteriorFinish exteriorFinish = ExteriorFinish.None;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesQuote);

            target.SetField("exteriorFinishChosen", ExteriorFinish.Custom);

            //Act
            decimal actual = salesQuote.FinishCost;

            //Assert
            decimal expected = 606.06m;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void FinishCostPropertyGet_None_ReturnCostOfExteriorFinishChosen()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.None;
            ExteriorFinish exteriorFinish = ExteriorFinish.None;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesQuote);

            target.SetField("exteriorFinishChosen", ExteriorFinish.None);

            //Act
            decimal actual = salesQuote.FinishCost;

            //Assert
            decimal expected = 0m;

            Assert.AreEqual(expected, actual);
        }

        /*
         * TotalOptions Property
         * 1 testing cases
         */
        [TestMethod]
        public void TotalOptionsPropertyGet_ReturnCostOfAccessoriesAndExteriorFinishChosen()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.None;
            ExteriorFinish exteriorFinish = ExteriorFinish.None;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesQuote);

            target.SetField("accessoriesChosen", Accessories.StereoSystem);
            target.SetField("exteriorFinishChosen", ExteriorFinish.Standard);

            //Act
            decimal actual = salesQuote.TotalOptions;

            //Assert
            decimal expected = 505.05m + 202.02m;

            Assert.AreEqual(expected, actual);
        }

        /*
         * SubTotal Property
         * 1 testing cases
         */
        [TestMethod]
        public void SubTotalPropertyGet_ReturnVehicleSalePriceAndTotalOptions()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.None;
            ExteriorFinish exteriorFinish = ExteriorFinish.None;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesQuote);

            target.SetField("accessoriesChosen", Accessories.StereoSystem);
            target.SetField("exteriorFinishChosen", ExteriorFinish.Standard);

            //Act
            decimal actual = salesQuote.SubTotal;

            //Assert
            decimal expected = 450m + 505.05m + 202.02m;

            Assert.AreEqual(expected, actual);
        }

        /*
         * SalesTax Property
         * 1 testing cases
         */
        [TestMethod]
        public void SalesTaxPropertyGet_ReturnSalesTax()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.None;
            ExteriorFinish exteriorFinish = ExteriorFinish.None;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesQuote);

            target.SetField("accessoriesChosen", Accessories.StereoSystem);
            target.SetField("exteriorFinishChosen", ExteriorFinish.Standard);

            //Act
            decimal actual = salesQuote.SalesTax;

            //Assert
            decimal expected = Math.Round(0.15m * (450m + 505.05m + 202.02m),2);

            Assert.AreEqual(expected, actual);
        }

        /*
         * Total Property
         * 1 testing cases
         */
        [TestMethod]
        public void TotalPropertyGet_Return_SumOfSubTotalAndSalesTax()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.None;
            ExteriorFinish exteriorFinish = ExteriorFinish.None;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesQuote);

            target.SetField("accessoriesChosen", Accessories.StereoSystem);
            target.SetField("exteriorFinishChosen", ExteriorFinish.Standard);

            //Act
            decimal actual = salesQuote.Total;

            //Assert
            decimal expected = (450m + 505.05m + 202.02m) + Math.Round(0.15m * (450m + 505.05m + 202.02m), 2);

            Assert.AreEqual(expected, actual);
        }

        /*
         * AmountDue Property
         * 1 testing cases
         */
        [TestMethod]
        public void AmountDuePropertyGet_Return_SubtractingTradeInAmountFromTotal()
        {
            //Arrange
            decimal vehicleSalePrice = 450m;
            decimal tradeInAmount = 400m;
            decimal salesTaxRate = 0.15m;
            Accessories accessories = Accessories.None;
            ExteriorFinish exteriorFinish = ExteriorFinish.None;

            SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessories, exteriorFinish);
            PrivateObject target = new PrivateObject(salesQuote);

            target.SetField("accessoriesChosen", Accessories.StereoSystem);
            target.SetField("exteriorFinishChosen", ExteriorFinish.Standard);

            //Act
            decimal actual = salesQuote.AmountDue;

            //Assert
            decimal expected = (450m + 505.05m + 202.02m) + Math.Round(0.15m * (450m + 505.05m + 202.02m), 2) - 400m;

            Assert.AreEqual(expected, actual);
        }
    }
}
