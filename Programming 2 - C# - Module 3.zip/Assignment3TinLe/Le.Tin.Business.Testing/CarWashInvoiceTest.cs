﻿/*
 * Name: Tin Le
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-09-19
 * Updated: 2022-09-20
 */

using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Le.Tin.Business.Testing
{
    [TestClass]
    public class CarWashInvoiceTest
    {
        /*
         * Constructor1: CarWashInvoice(decimal, decimal, decimal, decimal)
         * 10 testing cases (6 exceptions, 4 state initialize)
         */

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor1_NegativeProvincialSalesTaxRate_Exception()
        {
            //Arrange
            decimal provincialSalesTaxRate = -0.2m;
            decimal goodsAndServicesTaxRate = 0.15m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            //Act
            CarWashInvoice target = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor1_ProvincialSalesTaxRateGreaterThanOne_Exception()
        {
            //Arrange
            decimal provincialSalesTaxRate = 1.2m;
            decimal goodsAndServicesTaxRate = 0.15m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            //Act
            CarWashInvoice target = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor1_NegativeGoodsAndservicesTaxRate_Exception()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = -0.15m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            //Act
            CarWashInvoice target = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor1_GoodsAndServicesTaxRateGreaterThanOne_Exception()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 1.15m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            //Act
            CarWashInvoice target = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor1_NegativePackageCost_Exception()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 0.15m;
            decimal packageCost = -250m;
            decimal fragranceCost = 300m;

            //Act
            CarWashInvoice target = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor1_NegativeFragranceCost_Exception()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 0.15m;
            decimal packageCost = 250m;
            decimal fragranceCost = -300m;

            //Act
            CarWashInvoice target = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);
        }

        [TestMethod]
        public void Constructor1_ProvicialSalesTaxRate_Initialized()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 0.15m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            //Act
            CarWashInvoice carWashInvoice = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);

            //Assert
            decimal expected = 0.2m;
            decimal actual = carWashInvoice.ProvincialSalesTaxRate;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Constructor1_GoodsAndServicesTaxRate_Initialized()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 0.15m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            //Act
            CarWashInvoice carWashInvoice = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);

            //Assert
            decimal expected = 0.15m;
            decimal actual = carWashInvoice.GoodsAndServicesTaxRate;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Constructor1_PackageCost_Initialized()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 0.15m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            //Act
            CarWashInvoice carWashInvoice = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);
            PrivateObject target = new PrivateObject(carWashInvoice);

            //Assert
            decimal expected = 250m;
            decimal actual = (decimal) target.GetField("packageCost");

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Constructor1_FragranceCost_Initialized()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 0.15m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            //Act
            CarWashInvoice carWashInvoice = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);
            PrivateObject target = new PrivateObject(carWashInvoice);

            //Assert
            decimal expected = 300m;
            decimal actual = (decimal)target.GetField("fragranceCost");

            Assert.AreEqual(expected, actual);
        }

        /*
         * Constructor2: CarWashInvoice(decimal, decimal)
         * 8 testing cases (4 exceptions, 4 state initialize)
         */

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor2_NegativeProvincialSalesTaxRate_Exception()
        {
            //Arrange
            decimal provincialSalesTaxRate = -0.25m;
            decimal goodsAndServicesTaxRate = 0.15m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            //Act
            CarWashInvoice target = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor2_ProvincialSalesTaxRateGreaterThanOne_Exception()
        {
            //Arrange
            decimal provincialSalesTaxRate = 1.25m;
            decimal goodsAndServicesTaxRate = 0.15m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            //Act
            CarWashInvoice target = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor2_NegativeGoodsAndservicesTaxRate_Exception()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = -0.14m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            //Act
            CarWashInvoice target = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor2_GoodsAndServicesTaxRateGreaterThanOne_Exception()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 1.14m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            //Act
            CarWashInvoice target = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);
        }

        [TestMethod]
        public void Constructor2_ProvicialSalesTaxRate_Initialized()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 0.15m;
            
            //Act
            CarWashInvoice carWashInvoice = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);

            //Assert
            decimal expected = 0.2m;
            decimal actual = carWashInvoice.ProvincialSalesTaxRate;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Constructor2_GoodsAndServicesTaxRate_Initialized()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 0.14m;

            //Act
            CarWashInvoice carWashInvoice = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);

            //Assert
            decimal expected = 0.14m;
            decimal actual = carWashInvoice.GoodsAndServicesTaxRate;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Constructor2_PackageCost_Initialized()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 0.15m;
            
            //Act
            CarWashInvoice carWashInvoice = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            PrivateObject target = new PrivateObject(carWashInvoice);

            //Assert
            decimal expected = 0m;
            decimal actual = (decimal)target.GetField("packageCost");

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Constructor2_FragranceCost_Initialized()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 0.15m;

            //Act
            CarWashInvoice carWashInvoice = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            PrivateObject target = new PrivateObject(carWashInvoice);

            //Assert
            decimal expected = 0m;
            decimal actual = (decimal)target.GetField("fragranceCost");

            Assert.AreEqual(expected, actual);
        }

        /*
         * PackageCost Property
         * 4 testing cases
         */
        [TestMethod]
        public void PackageCostPropertyGet_ReturnState()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 0.15m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            CarWashInvoice target = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);

            //Act
            decimal actual = target.PackageCost;

            //Assert
            decimal expected = 250m;
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void PackageCostPropertySet_NegativePackageCost_Exception()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 0.15m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            CarWashInvoice target = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);

            //Act
            target.PackageCost = -200m;
        }

        [TestMethod]
        public void PackageCostPropertySet_ZeroOrPositive_UpdatesState()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 0.15m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            CarWashInvoice carWashInvoice = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);
            PrivateObject target = new PrivateObject(carWashInvoice);

            //Act
            carWashInvoice.PackageCost = 200m;

            //Assert 
            decimal expected = 200m;
            decimal actual = (decimal) target.GetField("packageCost");

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void PackageCostPropertySet_NegativePackageCost_StateNotUpdated()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 0.15m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            CarWashInvoice carWashInvoice = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);
            
            //Act
            try
            {
                carWashInvoice.PackageCost = -200m;
            }
            catch (ArgumentOutOfRangeException)
            {
                //Assert
                decimal expected = 250m;
                
                PrivateObject target = new PrivateObject(carWashInvoice);
                decimal actual = (decimal)target.GetField("packageCost");

                Assert.AreEqual(expected, actual);
            }           
        }

        /*
         * FragranceCost Property
         * 4 testing cases
         */
        [TestMethod]
        public void FragranceCostPropertyGet_ReturnState()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 0.15m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            CarWashInvoice target = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);

            //Act
            decimal actual = target.FragranceCost;

            //Assert
            decimal expected = 300m;
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void FragranceCostPropertySet_NegativeFragranceCost_Exception()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 0.15m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            CarWashInvoice target = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);

            //Act
            target.FragranceCost = -250m;
        }

        [TestMethod]
        public void FragranceCostPropertySet_ZeroOrPositive_UpdatesState()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 0.15m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            CarWashInvoice carWashInvoice = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);
            PrivateObject target = new PrivateObject(carWashInvoice);

            //Act
            carWashInvoice.FragranceCost = 350m;

            //Assert 
            decimal expected = 350m;
            decimal actual = (decimal)target.GetField("fragranceCost");

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void FragranceCostPropertySet_NegativeFragranceCost_StateNotUpdated()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 0.15m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            CarWashInvoice carWashInvoice = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);

            //Act
            try
            {
                carWashInvoice.FragranceCost = -350m;
            }
            catch (ArgumentOutOfRangeException)
            {
                //Assert
                decimal expected = 300m;

                PrivateObject target = new PrivateObject(carWashInvoice);
                decimal actual = (decimal)target.GetField("fragranceCost");

                Assert.AreEqual(expected, actual);
            }
        }

        /*
         * ProvincialSalesTaxCharged Property
         */
        [TestMethod]
        public void ProvincialSalesTaxChargedPropertyGet_ReturnProvincialSalesTaxCharged()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 0.15m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            CarWashInvoice target = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);

            //Act
            decimal actual = target.ProvincialSalesTaxCharged;

            //Assert
            decimal expected = 0m;
            Assert.AreEqual(expected, actual);
        }

        /*
         * GoodsAndServicesTaxCharged Property
         */
        [TestMethod]
        public void GoodsAndServicesTaxChargedPropertyGet_ReturnGoodsAndServicesTaxCharged()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 0.15m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            CarWashInvoice target = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);

            //Act
            decimal actual = target.GoodsAndServicesTaxCharged;

            //Assert
            decimal expected = Math.Round(82.5m,2);
            Assert.AreEqual(expected, actual);
        }

        /*
         * SubTotal Property
         */
        [TestMethod]
        public void SubTotalPropertyGet_ReturnSumOfPackageAndFragranceCost()
        {
            //Arrange
            decimal provincialSalesTaxRate = 0.2m;
            decimal goodsAndServicesTaxRate = 0.15m;
            decimal packageCost = 250m;
            decimal fragranceCost = 300m;

            CarWashInvoice target = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);

            //Act
            decimal actual = target.SubTotal;

            //Assert
            decimal expected = 250m + 300m;
            Assert.AreEqual(expected, actual);
        }
    }
}