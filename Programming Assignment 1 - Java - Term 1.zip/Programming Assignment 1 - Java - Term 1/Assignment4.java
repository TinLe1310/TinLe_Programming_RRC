/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created:   2022-01-07
 * Updated:   2022-01-27
 */

// Compute and output the circumference of a circle
public class Assignment4
{
    public static void main(String[] args)
    {
        double radius = 3.2;
        final double PI = 3.14;

        System.out.printf("The circumference of a circle with a radius of %f is %f.",radius,(radius * 2 * PI));
    }
}