/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created:   2022-01-07
 * Updated:   2022-01-27
 */

 // Calculate the square of the number from 1 to 9
public class Assignment1
{
    public static void main(String[] args)
    {
        int speed = 100;
        int speedInc = 40;
        while (speed >= 0)
        {
            speed -= speedInc;
        }
        System.out.printf("Speed: %d", speed);
    }

}