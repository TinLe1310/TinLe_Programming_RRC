/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created:   2022-01-07
 * Updated:   2022-01-27
 */

 // Calculate the average of 4 numbers
 public class Assignment2
 {
     public static void main(String[] args)
     {
         int a = 1;
         int b = 7; //I change the declared method here
         int c = 9;
         int d = 34;
         final int THE_TOTAL_NUMBER = 4; // add 4 as a constant, not a number anymore
         double average;

         average = (double)(a + b + c + d)/THE_TOTAL_NUMBER;

         System.out.printf("The average of the values %d, %d, %d and %d is %f.",a,b,c,d,average);
     }
 }
