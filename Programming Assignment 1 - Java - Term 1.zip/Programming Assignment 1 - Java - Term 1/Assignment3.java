/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created:   2022-01-07
 * Updated:   2022-01-27
 */

 // Convert Kilograms to Pounds
 public class Assignment3
 {
     public static void main(String[] args)
     {
         int weightInKilograms;
         double weightInPounds;
         final double POUNDS_RATIO = 0.454;

         // Convert 10 kilograms to pounds
         weightInKilograms = 10;
         weightInPounds = weightInKilograms / POUNDS_RATIO;
         System.out.printf("%d kilograms is %f pounds.\n\n",weightInKilograms,weightInPounds);

         // Convert 50 kilograms to pounds
         weightInKilograms = 50;
         weightInPounds = weightInKilograms / POUNDS_RATIO;
         System.out.printf("%d kilograms is %f pounds.\n\n",weightInKilograms,weightInPounds);

         // Convert 100 kilograms to pounds
         weightInKilograms = 100;
         weightInPounds = weightInKilograms / POUNDS_RATIO;
         System.out.printf("%d kilograms is %f pounds.\n",weightInKilograms,weightInPounds);
     }
 }