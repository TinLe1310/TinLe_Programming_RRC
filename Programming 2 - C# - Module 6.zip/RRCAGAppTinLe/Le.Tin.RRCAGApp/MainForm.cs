﻿using ACE.BIT.ADEV.CarWash;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Le.Tin.RRCAGApp
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            this.mnuFileExit.Click += MnuFileExit_Click;
            this.mnuHelpAbout.Click += MnuHelpAbout_Click;
            this.mnuFileOpenSalesQuote.Click += MnuFileOpenSalesQuote_Click;
            this.mnuFileOpenCarWash.Click += MnuFileOpenCarWash_Click;
            this.mnuDataVehicles.Click += MnuDataVehicles_Click;
        }

        /// <summary>
        /// Handles the Click event of the Vehicle menu item
        /// </summary>
        private void MnuDataVehicles_Click(object sender, EventArgs e)
        {
            VehicleDataForm form;
            form = new VehicleDataForm();

            //Make the Vehicle data form appear
            form.ShowDialog();
        }

        /// <summary>
        /// Handles the Click event of the car wash menu item
        /// </summary>
        private void MnuFileOpenCarWash_Click(object sender, EventArgs e)
        {
            CarWashForm form;
            form = new CarWashForm();
            form.MdiParent = this;


            //Make the Car wash form appear
            form.Show();
        }

        /// <summary>
        /// Handles the Click event of the sales quote menu item.
        /// </summary>
        private void MnuFileOpenSalesQuote_Click(object sender, EventArgs e)
        {
            SalesQuoteForm form;
            form = new SalesQuoteForm();

            // Make the Sales Quote form appear
            form.ShowDialog();
        }

        /// <summary>
        /// Handles the Click event of the about menu item.
        /// </summary>
        private void MnuHelpAbout_Click(object sender, EventArgs e)
        {
            AboutForm form;
            form = new AboutForm();

            // Make the About form appear
            form.ShowDialog();
        }

        /// <summary>
        /// Handles the Click event of the exit menu item.
        /// </summary>
        private void MnuFileExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
