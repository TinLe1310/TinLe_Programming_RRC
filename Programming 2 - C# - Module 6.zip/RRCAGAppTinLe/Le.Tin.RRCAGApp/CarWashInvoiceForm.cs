﻿using ACE.BIT.ADEV.CarWash;
using ACE.BIT.ADEV.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Le.Tin.Business;

namespace Le.Tin.RRCAGApp
{
    public partial class CarWashInvoiceForm : ACE.BIT.ADEV.Forms.CarWashInvoiceForm
    {
        private CarWashInvoice carWashInvoice;
        
        public CarWashInvoiceForm(CarWashInvoice invoice)
        {
            InitializeComponent();

            this.carWashInvoice = invoice;
            BindingControls();
        }

       private void BindingControls()
       {
            Binding packageCostBind = new Binding("Text", this.carWashInvoice, "packageCost");
            packageCostBind.FormattingEnabled = true;
            packageCostBind.FormatString = "C";
            this.lblPackagePrice.DataBindings.Add(packageCostBind);

            Binding fragranceCostBind = new Binding("Text", this.carWashInvoice, "fragranceCost");
            fragranceCostBind.FormattingEnabled = true;
            fragranceCostBind.FormatString = "N";
            this.lblFragrancePrice.DataBindings.Add(fragranceCostBind);

            Binding subTotalBind = new Binding("Text", this.carWashInvoice, "subTotal");
            subTotalBind.FormattingEnabled = true;
            subTotalBind.FormatString = "C";
            this.lblSubtotal.DataBindings.Add(subTotalBind);

            Binding PSTBind = new Binding("Text", this.carWashInvoice, "provincialSalesTaxCharged");
            PSTBind.FormattingEnabled = true;
            PSTBind.FormatString = "N";
            this.lblProvincialSalesTax.DataBindings.Add(PSTBind);

            Binding GSTBind = new Binding("Text", this.carWashInvoice, "goodsAndServicesTaxCharged");
            GSTBind.FormattingEnabled = true;
            GSTBind.FormatString = "N";
            this.lblGoodsAndServicesTax.DataBindings.Add(GSTBind);

            Binding totalBind = new Binding("Text", this.carWashInvoice, "total");
            totalBind.FormattingEnabled = true;
            totalBind.FormatString = "C";
            this.lblTotal.DataBindings.Add(totalBind);
        }
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // CarWashInvoiceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.ClientSize = new System.Drawing.Size(825, 484);
            this.Name = "CarWashInvoiceForm";
            this.Text = "Car Wash Invoice";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}