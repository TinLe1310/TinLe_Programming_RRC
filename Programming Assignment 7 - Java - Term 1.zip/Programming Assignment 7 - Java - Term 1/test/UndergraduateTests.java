/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created:   2022-04-10
 * Updated:   2022-04-10
 */

/**
 * A program to test the UndergraduateApplicant class
 *
 *@author Tin Le
 *@version 1.0
 */
 public class UndergraduateTests
 {
     public static void main(String[] args)
     {
         System.out.println("UndergraduateApplicant(String, String, double, double)");
         System.out.println("Test #1 - Initialize the name.");
         constructor_name_initialize();

         System.out.println("Test #2 - Initialize the college.");
         constructor_college_initialize();

         System.out.println("Test #3 - Initialize the mark achieved on the standard aptitude test below the allowable range.");
         constructor_mark_initialize_below_range();

         System.out.println("Test #4 - Initialize the mark achieved on the standard aptitude test above the allowable range.");
         constructor_mark_initialize_above_range();

         System.out.println("Test #5 - Initialize the mark achieved on the standard aptitude test at the edge of the allowable range.");
         constructor_mark_initialize_at_the_edge_range();

         System.out.println("Test #6 - Initialize the mark achieved on the standard aptitude test.");
         constructor_mark_initialize();

         System.out.println("Test #7 - Initialize the applicants grade point average below the allowable range.");
         constructor_grade_point_average_initialize_below_range();

         System.out.println("Test #8 - Initialize the applicants grade point average above the allowable range.");
         constructor_grade_point_average_initialize_above_range();

         System.out.println("Test #9 - Initialize the applicants grade point average at the edge of the  allowable range.");
         constructor_grade_point_average_initialize_at_the_edge_range();

         System.out.println("Test #10 - Initialize the applicants grade point average.");
         constructor_grade_point_average_initialize();

         System.out.println("setStandardAptitudeTestScore(double) : void");
         System.out.println("Test #1 - Update the mark achieved on the standard aptitude test below the allowable range.");
         update_mark_below_range();

         System.out.println("Test #2 - Update the mark achieved on the standard aptitude test above the allowable range.");
         update_mark_above_range();

         System.out.println("Test #3 - Update the mark achieved on the standard aptitude test at the edge of the allowable range.");
         update_mark_at_the_edge_range();

         System.out.println("Test #4 - Update the mark achieved on the standard aptitude test.");
         update_mark();

         System.out.println("setGradePointAverage(double) : void");
         System.out.println("Test #1 - Update the applicants grade point average below the allowable range.");
         update_grade_point_average_below_range();

         System.out.println("Test #2 - Update the applicants grade point average above the allowable range.");
         update_grade_point_average_above_range();

         System.out.println("Test #3 - Update the applicants grade point average at the edge of the allowable range.");
         update_grade_point_average_at_the_edge_range();

         System.out.println("Test #4 - Update the applicants grade point average.");
         update_grade_point_average();

         System.out.println("registerForProgram(String) : String");
         System.out.println("Test #1 - Returns a String indicating the college, program name, and aptitude test score");
         return_string_registration_for_program();

         System.out.println("toString() : String");
         System.out.println("Test #1 - Returns the correct String representation.");
         return_string_representation();
     }

    /*
     * Constructor - UndergraduateApplicant(String, String, double, double)
     */
     public static void constructor_name_initialize()
     {
         String name = "Tin Le";
         String college = "Red River College";
         double standardApptitudeTestScore = 200;
         double gradePointAverage = 4;

         UndergraduateApplicant target = new UndergraduateApplicant(name, college, standardApptitudeTestScore, gradePointAverage);

         String expected = "Tin Le";
         String actual = target.getName();

         System.out.printf("Expected: %s\nActual: %s\n\n",expected,actual);
     }

     public static void constructor_college_initialize()
     {
         String name = "Tin Le";
         String college = "Red River College";
         double standardApptitudeTestScore = 200;
         double gradePointAverage = 4;

         UndergraduateApplicant target = new UndergraduateApplicant(name, college, standardApptitudeTestScore, gradePointAverage);

         String expected = "Red River College";
         String actual = target.getCollege();

         System.out.printf("Expected: %s\nActual: %s\n\n",expected,actual);
     }

     public static void constructor_mark_initialize_below_range()
     {
         String name = "Tin Le";
         String college = "Red River College";
         double standardApptitudeTestScore = -400;
         double gradePointAverage = 4;

         UndergraduateApplicant target = new UndergraduateApplicant(name, college, standardApptitudeTestScore, gradePointAverage);

         double expected = 0;
         double actual = target.getStandardAptitudeTestScore();

         System.out.printf("Expected: %.1f\nActual: %.1f\n\n",expected,actual);
     }

     public static void constructor_mark_initialize_above_range()
     {
         String name = "Tin Le";
         String college = "Red River College";
         double standardApptitudeTestScore = 600;
         double gradePointAverage = 4;

         UndergraduateApplicant target = new UndergraduateApplicant(name, college, standardApptitudeTestScore, gradePointAverage);

         double expected = 0;
         double actual = target.getStandardAptitudeTestScore();

         System.out.printf("Expected: %.1f\nActual: %.1f\n\n",expected,actual);
     }

     public static void constructor_mark_initialize_at_the_edge_range()
     {
         String name = "Tin Le";
         String college = "Red River College";
         double standardApptitudeTestScore = 500;
         double gradePointAverage = 4;

         UndergraduateApplicant target = new UndergraduateApplicant(name, college, standardApptitudeTestScore, gradePointAverage);

         double expected = 500;
         double actual = target.getStandardAptitudeTestScore();

         System.out.printf("Expected: %.1f\nActual: %.1f\n\n",expected,actual);
     }

     public static void constructor_mark_initialize()
     {
         String name = "Tin Le";
         String college = "Red River College";
         double standardApptitudeTestScore = 400;
         double gradePointAverage = 4;

         UndergraduateApplicant target = new UndergraduateApplicant(name, college, standardApptitudeTestScore, gradePointAverage);

         double expected = 400;
         double actual = target.getStandardAptitudeTestScore();

         System.out.printf("Expected: %.1f\nActual: %.1f\n\n",expected,actual);
     }

     public static void constructor_grade_point_average_initialize_below_range()
     {
         String name = "Tin Le";
         String college = "Red River College";
         double standardApptitudeTestScore = 400;
         double gradePointAverage = -3;

         UndergraduateApplicant target = new UndergraduateApplicant(name, college, standardApptitudeTestScore, gradePointAverage);

         double expected = 0;
         double actual = target.getGradePointAverage();

         System.out.printf("Expected: %.2f\nActual: %.2f\n\n",expected,actual);
     }

     public static void constructor_grade_point_average_initialize_above_range()
     {
         String name = "Tin Le";
         String college = "Red River College";
         double standardApptitudeTestScore = 400;
         double gradePointAverage = 5;

         UndergraduateApplicant target = new UndergraduateApplicant(name, college, standardApptitudeTestScore, gradePointAverage);

         double expected = 0;
         double actual = target.getGradePointAverage();

         System.out.printf("Expected: %.2f\nActual: %.2f\n\n",expected,actual);
     }

     public static void constructor_grade_point_average_initialize_at_the_edge_range()
     {
         String name = "Tin Le";
         String college = "Red River College";
         double standardApptitudeTestScore = 400;
         double gradePointAverage = 4.5;

         UndergraduateApplicant target = new UndergraduateApplicant(name, college, standardApptitudeTestScore, gradePointAverage);

         double expected = 4.50;
         double actual = target.getGradePointAverage();

         System.out.printf("Expected: %.2f\nActual: %.2f\n\n",expected,actual);
     }

     public static void constructor_grade_point_average_initialize()
     {
         String name = "Tin Le";
         String college = "Red River College";
         double standardApptitudeTestScore = 400;
         double gradePointAverage = 4;

         UndergraduateApplicant target = new UndergraduateApplicant(name, college, standardApptitudeTestScore, gradePointAverage);

         double expected = 4;
         double actual = target.getGradePointAverage();

         System.out.printf("Expected: %.2f\nActual: %.2f\n\n",expected,actual);
     }

    /*
     * setStandardAptitudeTestScore(double) : void
     */
     public static void update_mark_below_range()
     {
         String name = "Tin Le";
         String college = "Red River College";
         double standardApptitudeTestScore = 400;
         double gradePointAverage = 4;

         UndergraduateApplicant target = new UndergraduateApplicant(name, college, standardApptitudeTestScore, gradePointAverage);
         target.setStandardAptitudeTestScore(-200);

         double expected = 0;
         double actual = target.getStandardAptitudeTestScore();

         System.out.printf("Expected: %.1f\nActual: %.1f\n\n",expected,actual);
     }

     public static void update_mark_above_range()
     {
         String name = "Tin Le";
         String college = "Red River College";
         double standardApptitudeTestScore = 400;
         double gradePointAverage = 4;

         UndergraduateApplicant target = new UndergraduateApplicant(name, college, standardApptitudeTestScore, gradePointAverage);
         target.setStandardAptitudeTestScore(600);

         double expected = 0;
         double actual = target.getStandardAptitudeTestScore();

         System.out.printf("Expected: %.1f\nActual: %.1f\n\n",expected,actual);
     }

     public static void update_mark_at_the_edge_range()
     {
         String name = "Tin Le";
         String college = "Red River College";
         double standardApptitudeTestScore = 400;
         double gradePointAverage = 4;

         UndergraduateApplicant target = new UndergraduateApplicant(name, college, standardApptitudeTestScore, gradePointAverage);
         target.setStandardAptitudeTestScore(500);

         double expected = 500;
         double actual = target.getStandardAptitudeTestScore();

         System.out.printf("Expected: %.1f\nActual: %.1f\n\n",expected,actual);
     }

     public static void update_mark()
     {
         String name = "Tin Le";
         String college = "Red River College";
         double standardApptitudeTestScore = 400;
         double gradePointAverage = 4;

         UndergraduateApplicant target = new UndergraduateApplicant(name, college, standardApptitudeTestScore, gradePointAverage);
         target.setStandardAptitudeTestScore(300);

         double expected = 300;
         double actual = target.getStandardAptitudeTestScore();

         System.out.printf("Expected: %.1f\nActual: %.1f\n\n",expected,actual);
     }

    /*
     * setGradePointAverage(double) : void
     */
     public static void update_grade_point_average_below_range()
     {
         String name = "Tin Le";
         String college = "Red River College";
         double standardApptitudeTestScore = 400;
         double gradePointAverage = 4;

         UndergraduateApplicant target = new UndergraduateApplicant(name, college, standardApptitudeTestScore, gradePointAverage);
         target.setGradePointAverage(-3);

         double expected = 0;
         double actual = target.getGradePointAverage();

         System.out.printf("Expected: %.2f\nActual: %.2f\n\n",expected,actual);
     }

     public static void update_grade_point_average_above_range()
     {
         String name = "Tin Le";
         String college = "Red River College";
         double standardApptitudeTestScore = 400;
         double gradePointAverage = 4;

         UndergraduateApplicant target = new UndergraduateApplicant(name, college, standardApptitudeTestScore, gradePointAverage);
         target.setGradePointAverage(6);

         double expected = 0;
         double actual = target.getGradePointAverage();

         System.out.printf("Expected: %.2f\nActual: %.2f\n\n",expected,actual);
     }

     public static void update_grade_point_average_at_the_edge_range()
     {
         String name = "Tin Le";
         String college = "Red River College";
         double standardApptitudeTestScore = 400;
         double gradePointAverage = 4;

         UndergraduateApplicant target = new UndergraduateApplicant(name, college, standardApptitudeTestScore, gradePointAverage);
         target.setGradePointAverage(4.5);

         double expected = 4.5;
         double actual = target.getGradePointAverage();

         System.out.printf("Expected: %.2f\nActual: %.2f\n\n",expected,actual);
     }

     public static void update_grade_point_average()
     {
         String name = "Tin Le";
         String college = "Red River College";
         double standardApptitudeTestScore = 400;
         double gradePointAverage = 4;

         UndergraduateApplicant target = new UndergraduateApplicant(name, college, standardApptitudeTestScore, gradePointAverage);
         target.setGradePointAverage(2);

         double expected = 2;
         double actual = target.getGradePointAverage();

         System.out.printf("Expected: %.2f\nActual: %.2f\n\n",expected,actual);
     }

    /*
     * registerForProgram(String) : String
     */
     public static void return_string_registration_for_program()
     {
         String name = "Tin Le";
         String college = "Red River College";
         double standardApptitudeTestScore = 400;
         double gradePointAverage = 4;
         String program = "Business information Technology";

         UndergraduateApplicant target = new UndergraduateApplicant(name, college, standardApptitudeTestScore, gradePointAverage);

         String expected = "Red River College - Business Information Technology [400.0]";
         String actual = target.registerForProgram(program);

         System.out.printf("Expected: %s\nActual: %s\n\n",expected,actual);
     }

    /*
     * toString() : String
     */
     public static void return_string_representation()
     {
         String name = "Tin Le";
         String college = "Red River College";
         double standardApptitudeTestScore = 400;
         double gradePointAverage = 4;

         UndergraduateApplicant target = new UndergraduateApplicant(name, college, standardApptitudeTestScore, gradePointAverage);

         String expected = "Undergraduate Applicant ** Tin Le - Red River College, SAT: 400.0, GPA: 4.00";
         String actual = target.toString();

         System.out.printf("Expected: %s\nActual: %s\n\n",expected,actual);
     }
}