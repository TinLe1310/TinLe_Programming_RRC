/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created:   2022-04-10
 * Updated:   2022-04-10
 */

/**
 * A program to test the GraduateApplicant class
 *
 *@author Tin Le
 *@version 1.0
 */

 public class GraduateApplicantTests
 {
     public static void main(String[] args)
     {
         System.out.println("GraduateApplicant(String, String, String)");
         System.out.println("Test #1 - Initialize the name.");
         constructor_name_initialize();

         System.out.println("Test #2 - Initialize the college.");
         constructor_college_initialize();

         System.out.println("Test #3 - Initialize the college of origin.");
         constructor_college_of_origin_initialize();

         System.out.println("setName(String): void");
         System.out.println("Test #1 - Update the state of name.");
         update_state_of_name();

         System.out.println("setCollege(String): void");
         System.out.println("Test #1 - Update the state of college.");
         update_state_of_college();

         System.out.println("setCollgeOfOrigin(String): void");
         System.out.println("Test #1 - Update the state of college of origin.");
         update_state_of_college_of_origin();

         System.out.println("isInside() : boolean");
         System.out.println("Test #1 - Returns true when the college and the college of origin are the same.");
         return_true_when_colleges_are_the_same();

         System.out.println("Test #2 - Returns false when the college and the college of origin are not the same.");
         return_false_when_colleges_are_not_the_same();

         System.out.println("registerForProgram(String) : String");
         System.out.println("Test #1 - Returns a String indicating the college of origin, college and program name");
         return_string_registration_for_program();

         System.out.println("toString() : String");
         System.out.println("Test #1 - Returns the correct String representation.");
         return_string_representation();
     }

    /*
     * Constructor - GraduateApplicant(String, String, String)
     */
     public static void constructor_name_initialize()
     {
         String name = "Tin Le";
         String college = "Red River College";
         String collegeOfOrigin = "HCMUT";

         GraduateApplicant target = new GraduateApplicant(name,college,collegeOfOrigin);

         String expected = "Tin Le";
         String actual = target.getName();

         System.out.printf("Expected: %s\nActual: %s\n\n",expected,actual);
     }

     public static void constructor_college_initialize()
     {
         String name = "Tin Le";
         String college = "Red River College";
         String collegeOfOrigin = "HCMUT";

         GraduateApplicant target = new GraduateApplicant(name,college,collegeOfOrigin);

         String expected = "Red River College";
         String actual = target.getCollege();

         System.out.printf("Expected: %s\nActual: %s\n\n",expected,actual);
     }

     public static void constructor_college_of_origin_initialize()
     {
         String name = "Tin Le";
         String college = "Red River College";
         String collegeOfOrigin = "HCMUT";

         GraduateApplicant target = new GraduateApplicant(name,college,collegeOfOrigin);

         String expected = "HCMUT";
         String actual = target.getCollegeOfOrigin();

         System.out.printf("Expected: %s\nActual: %s\n\n",expected,actual);
     }

    /*
     * setName(String): void
     */
     public static void update_state_of_name()
     {
         String name = "Tin Le";
         String college = "Red River College";
         String collegeOfOrigin = "HCMUT";

         GraduateApplicant target = new GraduateApplicant(name,college,collegeOfOrigin);
         target.setName("Justin");

         String expected = "Justin";
         String actual = target.getName();

         System.out.printf("Expected: %s\nActual: %s\n\n",expected,actual);
     }

    /*
     * setCollege(String): void
     */
     public static void update_state_of_college()
     {
         String name = "Tin Le";
         String college = "Red River College";
         String collegeOfOrigin = "HCMUT";

         GraduateApplicant target = new GraduateApplicant(name,college,collegeOfOrigin);
         target.setCollege("RRC");

         String expected = "RRC";
         String actual = target.getCollege();

         System.out.printf("Expected: %s\nActual: %s\n\n",expected,actual);
     }

    /*
     * setCollegeOfOrigin(String): void
     */
     public static void update_state_of_college_of_origin()
     {
         String name = "Tin Le";
         String college = "Red River College";
         String collegeOfOrigin = "HCMUT";

         GraduateApplicant target = new GraduateApplicant(name,college,collegeOfOrigin);
         target.setCollegeOfOrigin("HCM University of Technology");

         String expected = "HCM University of Technology";
         String actual = target.getCollegeOfOrigin();

         System.out.printf("Expected: %s\nActual: %s\n\n",expected,actual);
     }

    /*
     * isInside() : boolean
     */
     public static void return_true_when_colleges_are_the_same()
     {
         String name = "Tin Le";
         String college = "red river college";
         String collegeOfOrigin = "Red River College";

         GraduateApplicant target = new GraduateApplicant(name,college,collegeOfOrigin);

         String expected = "true";
         boolean actual = target.isInside();

         System.out.printf("Expected: %s\nActual: %s\n\n",expected,actual);
     }

     public static void return_false_when_colleges_are_not_the_same()
     {
         String name = "Tin Le";
         String college = "RRC";
         String collegeOfOrigin = "HCMUT";

         GraduateApplicant target = new GraduateApplicant(name,college,collegeOfOrigin);

         String expected = "false";
         boolean actual = target.isInside();

         System.out.printf("Expected: %s\nActual: %s\n\n",expected,actual);
     }

    /*
     * registerForProgram(String) : String
     */
     public static void return_string_registration_for_program()
     {
         String name = "Tin Le";
         String college = "Red River College";
         String collegeOfOrigin = "HCMUT";
         String program = "Business Information Technology";

         GraduateApplicant target = new GraduateApplicant(name,college,collegeOfOrigin);

         String expected = "HCMUT > Red River College - Business Information Technology";
         String actual = target.registerForProgram(program);

         System.out.printf("Expected: %s\nActual: %s\n\n",expected,actual);
     }

    /*
     * toString() : String
     */
     public static void return_string_representation()
     {
         String name = "Tin Le";
         String college = "Red River College";
         String collegeOfOrigin = "HCMUT";

         GraduateApplicant target = new GraduateApplicant(name,college,collegeOfOrigin);

         String expected = "Graduate Applicant: Tin Le - Red River College [HCMUT]";
         String actual = target.toString();

         System.out.printf("Expected: %s\nActual: %s\n\n",expected,actual);
     }
 }