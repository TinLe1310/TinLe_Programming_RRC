/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created:   2022-04-10
 * Updated:   2022-04-10
 */

 public class UndergraduateApplicant extends CollegeApplicant
 {
     private double standardAptitudeTestScore;
     private double gradePointAverage;

    /*
     * Initializes an instance of the UndergraduateApplicant class
     * with the specified applicant name, college name, standard aptitude test score and grade point average.
     *
     * @param name The name of the college applicant.
     * @param college The name of the college.
     * @param standardAptitudeTestScore The score achieved on the standard aptitude test.
     * @param gradePointAverage The applicants grade point average.
     */
     public UndergraduateApplicant(String name, String college, double standardAptitudeTestScore, double gradePointAverage)
     {
         super(name, college);
         setStandardAptitudeTestScore(standardAptitudeTestScore);
         setGradePointAverage(gradePointAverage);
     }

    /*
     * Returns the standard aptitude test score.
     *
     */
     public double getStandardAptitudeTestScore()
     {
         return this.standardAptitudeTestScore;
     }

    /*
     * Sets the standard aptitude test score.
     *
     * @param standardAptitudeTestScore The score achieved on the standard aptitude test.
     */
     public void setStandardAptitudeTestScore(double standardAptitudeTestScore)
     {
         if (standardAptitudeTestScore > 500.0)
         {
             this.standardAptitudeTestScore = 0;
         }
         else if (standardAptitudeTestScore < 0.0)
         {
             this.standardAptitudeTestScore = 0;
         }
         else this.standardAptitudeTestScore = standardAptitudeTestScore;
     }

    /*
     * Returns the grade point average.
     *
     */
     public double getGradePointAverage()
     {
         return this.gradePointAverage;
     }

    /*
     * Sets the grade point average.
     *
     * @param gradePointAverage The applicants grade point average.
     */
     public void setGradePointAverage(double gradePointAverage)
     {
         if (gradePointAverage > 4.50)
         {
             this.gradePointAverage = 0;
         }
         else if (gradePointAverage < 0.00)
         {
             this.gradePointAverage = 0;
         }
         else this.gradePointAverage = gradePointAverage;
     }

    /*
     * Returns a String representing the registration of a program.
     *
     * @param program The name of the program the college applicant is registering for.
     */
     public String registerForProgram(String program)
     {
         String template = "%s - %s [%.1f]";
         return String.format(template,getCollege(),program,this.standardAptitudeTestScore);
     }

    /*
     * Returns a String representation of the class.
     *
     */
     public String toString()
     {
         String template = "Undergraduate Applicant ** %s, SAT: %.1f, GPA: %.2f";
         return String.format(template,super.toString(),this.standardAptitudeTestScore,this.gradePointAverage);
     }
 }