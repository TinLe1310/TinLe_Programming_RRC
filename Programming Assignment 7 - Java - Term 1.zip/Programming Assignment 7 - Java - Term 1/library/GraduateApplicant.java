/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created:   2022-04-10
 * Updated:   2022-04-10
 */

 public class GraduateApplicant extends CollegeApplicant
 {
     private String collegeOfOrigin;

    /*
     * Initializes an instance of the GraduateApplicant class
     * with a specified name, college name, and college of origin.
     *
     * @param name The name of the college applicant.
     * @param college The name of the college.
     * @param collegeOfOrigin The name of the college where the graduate applicant received their degree.
     */
     public GraduateApplicant(String name, String college, String collegeOfOrigin)
     {
         super(name,college);
         setCollegeOfOrigin(collegeOfOrigin);
     }

    /*
     * Returns the college of origin.
     *
     */
     public String getCollegeOfOrigin()
     {
         return this.collegeOfOrigin;
     }

    /*
     * Sets the college of origin.
     *
     * @param collegeOfOrigin The name of the college where the graduate applicant received their degree.
     */
     public void setCollegeOfOrigin(String collegeOfOrigin)
     {
         this.collegeOfOrigin = collegeOfOrigin;
     }

    /*
     * Returns true when the college name and the college of origin are the same
     * (case should not be a factor); otherwise false.
     *
     */
     public boolean isInside()
     {
         boolean isInside = false;
         if(this.collegeOfOrigin.equalsIgnoreCase(getCollege()))
         {
             isInside = true;
         }
         return isInside;
     }

    /*
     * Returns a String representing the registration of a program.
     *
     * @param program The name of the program the college applicant is registering for.
     */
     public String registerForProgram(String program)
     {
         String template = "%s > %s - %s";
         return String.format(template,this.collegeOfOrigin,getCollege(),program);
     }

    /*
     * Returns a String representation of the class.
     *
     */
     public String toString()
     {
         String template = "Graduate Applicant: %s [%s]";
         return String.format(template,super.toString(),collegeOfOrigin);
     }
 }