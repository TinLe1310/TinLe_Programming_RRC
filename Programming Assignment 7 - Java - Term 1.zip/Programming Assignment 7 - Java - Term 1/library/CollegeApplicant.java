/*
 * Name:  Tin Le
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created:   2022-04-10
 * Updated:   2022-04-10
 */

 public abstract class CollegeApplicant
 {
     private String name;
     private String college;

    /*
     * Initializes an instance of the CollegeApplicant class
     * where the name and college are set to �unknown�.
     *
     */
     public CollegeApplicant()
     {
         this("unknown","unknown");
     }

    /*
     * Initializes an instance of the CollegeApplicant class
     * where the name and college are set to the specified values.
     *
     * @param name The name of the college applicant.
     * @param college The name of the college.
     */
     public CollegeApplicant(String name, String college)
     {
         setName(name);
         setCollege(college);
     }

    /*
     * Returns the college applicant�s name.
     *
     */
     public String getName()
     {
         return this.name;
     }

    /*
     * Sets the college applicant�s name.
     *
     *@param name The name of the college applicant.
     */
     public void setName(String name)
     {
         this.name = name;
     }

    /*
     * Returns the name of the college.
     *
     */
     public String getCollege()
     {
         return this.college;
     }

    /*
     *  Sets the name of the college.
     *
     *@param college The name of the college.
     */
     public void setCollege(String college)
     {
         this.college = college;
     }

    /*
     * Returns a String representing the registration of a program.
     *
     *@param program The name of the program the college applicant is registering for.
     */
     public abstract String registerForProgram(String program);

    /*
     * Returns a String representation of the class.
     *
     */
     public String toString()
     {
         String template = "%s - %s";
         return String.format(template,this.name,this.college);
     }
 }